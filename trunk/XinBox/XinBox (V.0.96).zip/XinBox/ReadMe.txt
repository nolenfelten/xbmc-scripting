XinBox By: Stanley87

Hi, thanks for using XinBox by Stanley87.

Some things to know before using:

1) Y to get help, press Y on basically anything to get some help. It will tell you the different buttons to use
   to access different features of XinBox.

2) XinBox also supports Keyboard and Remote Use:
   
   Back Button = Keyboard: Esc Button  Remote: Menu Button
   A Button = Keyboard: Enter Button   Remote: Select Button
   Y Button = Keyboard: Menu Button    Remote: Info Button
   B Button = Keyboard: Backspace Button  Remote: Title Button
   White Button = Keyboard: TAB Button    Remote: Display Button

3) Gmail Users:

	Please make sure your Gmail settings are ok.

	Go into your Gmail inbox, go to settings, go to forwarding and pop

	Click "Enable pop for all email that arrives from now on"

	XinBox will only work with this settings not "Enable pop for all email that has already been downloaded" as this causes issues.

	Also, with Gmail, there pop server works differently to other ISP's.

	They basically have two servers, one is your main inbox (web) and the second is a pop inbox. When emails are accessed via pop, gmail deletes them from its pop inbox. They will still remain in your main server(web) tho. 

	Hence, there is no way for Xinbox to delete them from server as Gmail has done this. So, for Gmail inboxes. XinBox can not delete from server/delete emails when they are received .Also, the server size label will always show server is empty.

	So, don�t panic, they will still be in your main gmail inbox as Xinbox wont touch this at all.

	Ps: This script works best with proper POP3 Email Servers (eg. your ISP supplied email addresses)

That is all.

Thanks.

Stanley87
