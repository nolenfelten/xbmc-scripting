"""
    Plugin Maker: This plugin will create a directory listing of VIDEO_PATH and add videos.
"""

# main imports
import os
import sys
import xbmc
import xbmcgui
import xbmcplugin

import datetime
import traceback


class _Info:
    def __init__( self, *args, **kwargs ):
        self.__dict__.update( kwargs )


class Main:
    # base paths
    BASE_CACHE_PATH = os.path.join( "P:\\", "Thumbnails", "Video" )
    # add all video extensions wanted in lowercase
    VIDEO_EXT = ".m4v|.3gp|.nsv|.ts|.ty|.strm|.pls|.rm|.rmvb|.m3u|.ifo|.mov|.qt|.divx|.xvid|.bivx|.vob|.nrg|.img|.iso|.pva|.wmv|.asf|.asx|.ogm|.m2v|.avi|.bin|.dat|.mpg|.mpeg|.mp4|.mkv|.avc|.vp3|.svq3|.nuv|.viv|.dv|.fli|.flv|.rar|.001|.wpl|.zip|.vdr|.dvr-ms|.xsp"

    def __init__( self ):
        if ( not sys.argv[ 2 ] ):
            self.get_settings()
            self.get_items( self.args.path )
        else:
            self._parse_argv()
            if ( self.args.isFolder ):
                self.get_items( self.args.path )

    def get_settings( self ):
        try:
            import re
            arg_string = ""
            f = open( os.path.join( os.getcwd().replace( ";", "" ), "settings.xml" ), "r" )
            data = f.read()
            f.close()
            pattern = '<setting (.*?)>(.*?)</setting>'
            items = re.findall( pattern, data, re.IGNORECASE )
            pattern = 'name=\"(.*)\"'
            type_pattern = 'type=\"([a-z]*)\"'
            for item in items:
                name = re.findall( pattern, item[ 0 ], re.IGNORECASE )
                stype = re.findall( type_pattern, item[ 0 ], re.IGNORECASE )
                if ( stype[ 0 ] == "str" ):
                    fstr = '%s="""%s""",'
                else:
                    fstr = '%s=%s,'
                arg_string += fstr % ( name[ 0 ], item[ 1 ], )
            exec "self.args = _Info(%s)" % ( arg_string[ : -1 ], )
        except:
            traceback.print_exc()

    def _parse_argv( self ):
        # call _Info() with our formatted argv to create the self.args object
        exec "self.args = _Info(%s)" % ( sys.argv[ 2 ][ 1 : ].replace( "&", ", " ), )
        self.args.path = self.args.path.replace( "[[BACKSLASH]]", "\\" )

    def get_items( self, path ):
        try:
            if ( path.startswith( "smb://" ) ):
                entries = self.get_samba_list( path )
            else:
                entries = os.listdir( path )
            # get the item list by walking VIDEO_PATH recursively
            items = self.add_items( path, entries )
            # fill media list
            ok = self._fill_media_list( items )
        except:
            traceback.print_exc()
            # oops print error message
            print sys.exc_info()[ 1 ]
            ok = False
        # send notification we're finished, successfully or unsuccessfully
        xbmcplugin.endOfDirectory( handle=int( sys.argv[ 1 ] ), succeeded=ok )

    def get_samba_list( self, path ):
        entries = []
        from TheaterAPI import smb
        from TheaterAPI import nmb
        share_string_list = path.split( "/" )
        remote_name = share_string_list[ 2 ]
        remote_ip = nmb.NetBIOS().gethostbyname( remote_name )[ 0 ].get_ip()
        remote_share = share_string_list[ 3 ]
        remote_object = smb.SMB( remote_name, remote_ip )
        if ( remote_object.is_login_required() ):
            remote_object.login( self.args.username, self.args.password )
        files = remote_object.list_path( remote_share, "/".join( share_string_list[ 4 : ] ) + "/*" )
        for file in files:
            #print file.get_longname(), file.is_directory()
            if ( file.get_longname() != "." and file.get_longname() != ".." ):
                entries += [ file.get_longname() ]
        return entries

    def add_items( self, path, entries ):
        items = []
        # enumerate through the list of files and check for a valid video file
        for entry in entries:
            # create the file path
            file_path = os.path.join( path, entry )
            # is this a folder?
            isFolder = os.path.isdir( file_path )
            # if this is a file, check to see if it's a valid video file
            if ( not isFolder ):
                # get the files extension
                ext = os.path.splitext( entry )[ 1 ].lower()
                # if it is a video file add it to our items list
                if ( ext and ext in self.VIDEO_EXT ):
                    items += [ ( file_path, isFolder, ) ]
            else:
                # it must be a folder
                items += [ ( file_path, isFolder, ) ]
        return items

    def _fill_media_list( self, items ):
        try:
            ok = True
            # enumerate through the list of items and add the item to the media list
            for item in items:
                # create our url
                url = '%s?path="""%s"""&isFolder=%d&username="""%s"""&password="""%s"""&intro_path="""%s"""&number_trailers=%d' % ( sys.argv[ 0 ], item[ 0 ].replace( "\\", "[[BACKSLASH]]" ), item[ 1 ], self.args.username, self.args.password, self.args.intro_path, self.args.number_trailers, )
                if ( item[ 1 ] ):
                    # if a folder.jpg exists use that for our thumbnail
                    #thumbnail = "%s.jpg" % ( os.path.dirname( item[ 0 ] ), )
                    #if ( not os.path.isfile( thumbnail ) ):
                    thumbnail = "DefaultFolderBig.png"
                    # parse item for title
                    title = os.path.basename( item[ 0 ] )
                    # only need to add label and thumbnail, setInfo() and addSortMethod() takes care of label2
                    listitem=xbmcgui.ListItem( label=title, thumbnailImage=thumbnail )
                else:
                    # call _get_thumbnail() for the path to the cached thumbnail
                    thumbnail = self._get_thumbnail( item[ 0 ] )
                    # parse item for title
                    title = os.path.splitext( os.path.basename( item[ 0 ] ) )[ 0 ]
                    # get the date of the file
                    date = datetime.datetime.fromtimestamp( os.path.getmtime( item[ 0 ] ) ).strftime( "%d-%m-%Y" )
                    # get the size of the file
                    size = os.path.getsize( item[ 0 ] )
                    # only need to add label and thumbnail, setInfo() and addSortMethod() takes care of label2
                    listitem=xbmcgui.ListItem( label=title, thumbnailImage=thumbnail )
                    # add the different infolabels we want to sort by
                    listitem.setInfo( type="Video", infoLabels={ "Title": title, "Date": date, "Size": size } )
                # add the item to the media list
                ok = xbmcplugin.addDirectoryItem( handle=int( sys.argv[ 1 ] ), url=url, listitem=listitem, isFolder=item[ 1 ], totalItems=len( items ) )
                # if user cancels, call raise to exit loop
                if ( not ok ): raise
        except:
            traceback.print_exc()
            # user cancelled dialog or an error occurred
            print sys.exc_info()[ 1 ]
            ok = False
        # if successful and user did not cancel, add all the required sort methods
        if ( ok ):
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_SIZE )
        return ok

    def _get_thumbnail( self, item ):
        # make the proper cache filename and path so duplicate caching is unnecessary
        filename = xbmc.getCacheThumbName( item )
        thumbnail = xbmc.translatePath( os.path.join( self.BASE_CACHE_PATH, filename[ 0 ], filename ) )
        # if the cached thumbnail does not exist create the thumbnail
        if ( not os.path.isfile( thumbnail ) ):
            # create filepath to a local tbn file
            thumbnail = os.path.splitext( item )[ 0 ] + ".tbn"
            # if there is no local tbn file use a default
            if ( not os.path.isfile( thumbnail ) ):
                thumbnail = "defaultVideoBig.png"
        return thumbnail


if ( __name__ == "__main__" ):
    Main()
