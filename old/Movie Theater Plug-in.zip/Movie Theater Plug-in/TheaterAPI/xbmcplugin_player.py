"""
    Movie Theater: Module plays random trailers then plays selected video
"""

# create the progress dialog (we do it here so there is minimal delay with nothing displayed)
import xbmcgui
pDialog = xbmcgui.DialogProgress()
pDialog.create( "Movie Theater Plug-in", "Getting random trailers..." )

# main imports
import sys
import os
import xbmc

from pysqlite2 import dbapi2 as sqlite


class _Info:
    def __init__( self, *args, **kwargs ):
        self.__dict__.update( kwargs )


class Main:
    # base paths
    BASE_CACHE_PATH = os.path.join( "P:\\", "Thumbnails", "Video" )
    BASE_SETTINGS_PATH = sys.modules[ "__main__" ].BASE_DATABASE_PATH

    def __init__( self ):
        self._parse_argv()
        self.settings = self.get_settings()
        self.play_videos()

    def _parse_argv( self ):
        # call _Info() with our formatted argv to create the self.args object
        exec "self.args = _Info(%s)" % ( sys.argv[ 2 ][ 1 : ].replace( "&", ", " ), )
        self.args.path = self.args.path.replace( "[[BACKSLASH]]", "\\" )

    def play_videos( self ):
        # call _get_thumbnail() for the path to the cached thumbnail
        thumbnail = self._get_thumbnail( sys.argv[ 0 ] + sys.argv[ 2 ] )
        playlist = xbmc.PlayList( 1 )
        playlist.clear()
        if ( self.args.intro_path ):
            playlist.add( self.args.intro_path )
        
        trailers = self._fetch_records()
        for trailer in trailers:
            url = self._get_trailer_url( eval( trailer[ 3 ] ) )
            playlist.add( url )
        #print self.args.path
        playlist.add( self.args.path )
        pDialog.close()
        if ( not pDialog.iscanceled() ):
            #listitem = xbmcgui.ListItem( self.args.title, thumbnailImage=thumbnail )
            #listitem.setInfo( "video", { "Title": self.args.title, "Director": self.args.director, "Genre": self.args.genre, "Rating": self.args.rating, "Count": self.args.count, "Date": self.args.date } )
            xbmc.Player().play( playlist )
        # TODO: maybe call endOfDirectory()

    def _fetch_records( self ):
        records = Records()
        sql = "SELECT * FROM movies WHERE trailer_urls IS NOT NULL AND movies.trailer_urls!='[]' ORDER BY RANDOM() LIMIT %d"
        result = records.fetch( sql % ( self.args.number_trailers, ) )
        records.close()
        return result

    def _get_thumbnail( self, url ):
        # make the proper cache filename and path
        filename = xbmc.getCacheThumbName( url )
        filepath = xbmc.translatePath( os.path.join( self.BASE_CACHE_PATH, filename[ 0 ], filename ) )
        return filepath

    def _get_trailer_url( self, trailer_urls ):
        url = ""
        # get intial choice
        choice = ( int( self.settings[ "trailer_quality" ] ), len( trailer_urls ) - 1, )[ int( self.settings[ "trailer_quality" ] ) >= len( trailer_urls ) ]
        # if quality is non progressive
        if ( int( self.settings[ "trailer_quality" ] ) <= 2 ):
            # select the correct non progressive trailer
            while ( trailer_urls[ choice ].endswith( "p.mov" ) and choice != -1 ): choice -= 1
        # quality is progressive
        else:
            # select the proper progressive quality
            quality = ( "480p", "720p", "1080p", )[ int( self.settings[ "trailer_quality" ] ) - 3 ]
            # select the correct progressive trailer
            while ( quality not in trailer_urls[ choice ] and trailer_urls[ choice ].endswith( "p.mov" ) and choice != -1 ): choice -= 1
        # if there was a valid trailer set it
        if ( choice >= 0 ):
            url = trailer_urls[ choice ]
        return url

    def get_settings( self ):
        try:
            settings_file = open( os.path.join( self.BASE_SETTINGS_PATH, "settings.txt" ), "r" )
            settings = eval( settings_file.read() )
            settings_file.close()
        except:
            settings = { "trailer_quality": 2 }
        return settings


class Records:
    # base paths
    BASE_DATABASE_PATH = sys.modules[ "__main__" ].BASE_DATABASE_PATH

    def __init__( self, *args, **kwargs ):
        self.connect()

    def connect( self ):
        self.db = sqlite.connect( os.path.join( self.BASE_DATABASE_PATH, "AMT.db" ) )
        self.cursor = self.db.cursor()
    
    def close( self ):
        self.db.close()
    
    def fetch( self, sql, params=None ):
        try:
            if ( params is not None ): self.cursor.execute( sql, params )
            else: self.cursor.execute( sql )
            retval = self.cursor.fetchall()
        except:
            retval = None
        return retval

