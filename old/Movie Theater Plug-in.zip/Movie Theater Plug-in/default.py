"""
    Movie Theater: Plug-in for viewing random trailers from Apple.com before viewing the  main movie
"""
# main imports
import os
import sys

# plugin constants
__plugin__ = "Movie Theater"
__author__ = "nuka1195"
__credits__ = "Team XBMC"
__version__ = "1.0"

# base paths
BASE_PATH = os.getcwd().replace( ";", "" )
BASE_DATABASE_PATH = xbmc.translatePath( os.path.join( "P:\\", "script_data", "Apple Movie Trailers" ) )


if ( __name__ == "__main__" ):
    if ( "isFolder=0" in sys.argv[ 2 ] ):
        from TheaterAPI import xbmcplugin_player as plugin
    else:
        from TheaterAPI import xbmcplugin_list as plugin
    plugin.Main()
