"""
    Player module: plays the selected video
"""

# TODO: remove this when dialog issue is resolved
import xbmc
# set our title
g_title = xbmc.getInfoLabel( "ListItem.Title" )
# set our studio
g_studio = xbmc.getInfoLabel( "ListItem.Studio" )
# set our genre
g_genre = xbmc.getInfoLabel( "ListItem.Genre" )

# create the progress dialog (we do it here so there is minimal delay with nothing displayed)
import xbmcgui
pDialog = xbmcgui.DialogProgress()
pDialog.create( "AOL Videos Plugin", "Downloading video..." )

# main imports
import sys
import os
##import xbmc
import xbmcplugin

import urllib


class _Info:
    def __init__( self, *args, **kwargs ):
        self.__dict__.update( kwargs )


class Main:
    # base paths
    BASE_CACHE_PATH = os.path.join( "P:\\", "Thumbnails", "Video" )

    def __init__( self ):
        self._get_settings()
        # parse argv for our download url
        self._parse_argv()
        # download the video
        filepath = self._download_video( self.args.download_url )
        # play the video
        self._play_video( filepath )

    def _parse_argv( self ):
        # call _Info() with our formatted argv to create the self.args object
        exec "self.args = _Info(%s)" % ( sys.argv[ 2 ][ 1 : ].replace( "&", ", " ).replace( "\\u0027", "'" ).replace( "\\u0022", '"' ).replace( "\\u0026", "&" ), )

    def _get_settings( self ):
        self.settings = {}
        self.settings[ "mode" ] = xbmcplugin.getSetting( "mode" )
        self.settings[ "download_path" ] = xbmcplugin.getSetting( "download_path" )

    def _download_video( self, url ):
        try:
            # construct an xbox compatible filepath
            ext = os.path.splitext( url )[ 1 ]
            if ( len( ext ) != 4 ):
                ext = ".avi"
            if ( self.settings[ "mode" ] == "Download" ):
                filepath = "Z:\\AOLVideo%s" % ( ext, )
            else:
                # replace forward and back slashes, split at colon and replace leading and trailing apostrophes
                title = g_title.replace( "/", "" ).replace( "\\", "" ).split( ": " )
                if ( title[ -1 ].startswith( "'" ) and title[ -1 ].endswith( "'" ) ):
                    title[ -1 ] = title[ -1 ][ 1 : -1 ]
                # join back together
                title = "-".join( title )
                # get a valid filepath
                filepath = self._make_legal_filepath( os.path.join( self.settings[ "download_path" ], title + ext ) )
            if ( not os.path.isfile( filepath ) or self.settings[ "mode" ] == "Download" ):
                # fetch the video
                urllib.urlretrieve( url, filepath, self._report_hook )
        except:
            if ( os.path.isfile( filepath ) ):
                os.remove( filepath )
            filepath = ""
            pDialog.close()
        return filepath

    def _report_hook( self, count, blocksize, totalsize ):
        percent = int( float( count * blocksize * 100) / totalsize )
        pDialog.update( percent )
        if ( pDialog.iscanceled() ): raise

    def _make_legal_filepath( self, path, compatible=False, extension=True, conf=True, save_end=False ):
        environment = os.environ.get( "OS", "xbox" )
        if ( environment == "win32" or environment == "xbox" ):
            path = path.replace( "\\", "/" )
        drive = os.path.splitdrive( path )[ 0 ]
        parts = os.path.splitdrive( path )[ 1 ].split( "/" )
        if ( not drive and parts[ 0 ].endswith( ":" ) and len( parts[ 0 ] ) == 2 and compatible ):
            drive = parts[ 0 ]
            parts[ 0 ] = ""
        if ( environment == "xbox" or environment == "win32" or compatible ):
            illegal_characters = """,*=|<>?;:"+"""
            length = ( 42 - ( conf * 5 ) )
            for count, part in enumerate( parts ):
                tmp_name = ""
                for char in part:
                    # if char's ord() value is > 127 or an illegal character remove it
                    if ( char in illegal_characters or ord( char ) > 127 ): char = ""
                    tmp_name += char
                if ( environment == "xbox" or compatible ):
                    if ( len( tmp_name ) > length ):
                        if ( count == len( parts ) - 1 and extension == True ):
                            filename = os.path.splitext( tmp_name )[ 0 ]
                            ext = os.path.splitext( tmp_name )[ 1 ]
                            if ( save_end ):
                                tmp_name = filename[ : 35 - len( ext ) ] + filename[ -2 : ]
                            else:
                                tmp_name = filename[ : 37 - len( ext ) ]
                            tmp_name = "%s%s" % ( tmp_name.strip(), ext )
                        else:
                            tmp_name = tmp_name[ : 42 ].strip()
                parts[ count ] = tmp_name
        filepath = drive + "/".join( parts )
        if ( environment == "win32" ):
            return filepath.encode( "utf-8" )
        else:
            return filepath

    def _play_video( self, filepath ):
        if ( filepath ):
            # call _get_thumbnail() for the path to the cached thumbnail
            thumbnail = self._get_thumbnail( sys.argv[ 0 ] + sys.argv[ 2 ] )
            # set the default icon
            icon = "DefaultVideo.png"
            pDialog.close()
            # only need to add label, icon and thumbnail, setInfo() and addSortMethod() takes care of label2
            listitem = xbmcgui.ListItem( g_title, iconImage=icon, thumbnailImage=thumbnail )
            # set the key information
            listitem.setInfo( "video", { "Title": g_title, "Genre": g_genre, "Studio": g_studio } )
            xbmc.Player().play( filepath, listitem )

    def _get_thumbnail( self, url ):
        # make the proper cache filename and path
        filename = xbmc.getCacheThumbName( url )
        filepath = xbmc.translatePath( os.path.join( self.BASE_CACHE_PATH, filename[ 0 ], filename ) )
        return filepath
