import os
import shutil
from pysqlite2 import dbapi2 as sqlite
import xbmcgui

def get_browse_dialog( default="", heading="", type=1, shares="files", mask="", use_thumbs=False, treat_as_folder=False ):
    """ shows a browse dialog and returns a value
        - 0 : ShowAndGetDirectory
        - 1 : ShowAndGetFile
        - 2 : ShowAndGetImage
        - 3 : ShowAndGetWriteableDirectory
    """
    dialog = xbmcgui.Dialog()
    value = dialog.browse( type, heading, shares, mask, use_thumbs, treat_as_folder, default )
    return value

def copy_thumbs( paths, base_cache_path ):
    dialog = xbmcgui.DialogProgress()
    dialog.create( "Exporting cached thumbs" )
    for count, path in enumerate( paths ):
        if ( dialog.iscanceled() ): break
        try:
            percent = int( ( count +1 ) * ( float( 100 ) / len( paths ) ) )
            thumb = xbmc.getCacheThumbName( path.replace( "\r\n", "" ).replace( "\r", "" ).replace( "\n", "" ) )
            cached_thumb = os.path.join( base_cache_path, thumb )
            if ( not save_as_folder ):
                finished_thumb = "%s.tbn" % os.path.join( thumb_folder, os.path.splitext( os.path.split( path.replace( "\r\n", "" ).replace( "\r", "" ).replace( "\n", "" ) )[ 1 ] )[ 0 ] )
            else:
                finished_thumb = os.path.join( thumb_folder, os.path.splitext( os.path.split( path.replace( "\r\n", "" ).replace( "\r", "" ).replace( "\n", "" ) )[ 1 ] )[ 0 ], "folder.jpg" )
            dialog.update( percent, "Current file: %s" % os.path.split( cached_thumb )[ 1 ], "To: %s" % finished_thumb )
            if ( not os.path.isdir( os.path.split( finished_thumb )[ 0 ] ) ):
                os.makedirs( os.path.split( finished_thumb )[ 0 ] )
            shutil.copy( cached_thumb, finished_thumb )
        except:
            pass
    dialog.close()

def read_path_file( file_path ):
    try:
        if ( "videos" in file_path.lower() ):
            sql = "SELECT path.strpath, files.strfilename FROM files, path WHERE files.idpath=path.idpath ORDER BY strfilename;"
            base_cache_path = "q:\\UserData\\Thumbnails\\Video"
        else:
            raise
        #elif ( "music" in file_path.lower() ):
        #    sql = "SELECT path.strpath, files.strfilename FROM files, path WHERE files.idpath=path.idpath ORDER BY strfilename;"
        #    base_cache_path = "q:\\UserData\\Thumbnails\\Video"
            
        if ( file_path.endswith( ".txt" ) ):
            file_object = open( os.path.join( file_path ), "r" )
            paths = file_object.readlines()
            file_object.close()
        else:
            db = sqlite.connect( file_path )
            cursor = db.cursor()
            cursor.execute( sql )
            tmp_paths = cursor.fetchall()
            db.close()
            paths = []
            if ( tmp_paths ):
                for path in tmp_paths:
                    paths += [ os.path.join( path[ 0 ], path[ 1 ] ) ]
    except:
        paths = []
        base_cache_path = ""
    return paths, base_cache_path


if ( __name__ == "__main__" ):
    file_path = get_browse_dialog( "q:\\UserData\\Database", "database or text file", 1, "files", ".db|.txt" )
    if ( file_path.endswith( ".txt" ) or file_path.endswith( ".db" ) ):
        thumb_folder = get_browse_dialog( "f:\\", "export folder", 3, "files" )
        save_as_folder = xbmcgui.Dialog().yesno( "Save method", "Save the thumbs as folder.jpg?", "", "", "name.tbn", "folder.jpg" )
        paths, base_cache_path = read_path_file( file_path )
        if ( paths ):
            copy_thumbs( paths, base_cache_path )
    