import os,sys,urllib,time,re,socket,string,traceback
import xbmcplugin,xbmcgui

ROOT_DIR = os.getcwd()[:-1]+'\\'
dialogProgress = xbmcgui.DialogProgress()
class TVLink:
    def __init__(self):
        try:
            self.Cats = ["Shows", "Cartoons", "Documentaries", "Anime", "Movies", "Music Videos"]
            self.Links = ["http://www.tv-links.co.uk/index.do/1", "http://www.tv-links.co.uk/index.do/2", "http://www.tv-links.co.uk/index.do/9", "http://www.tv-links.co.uk/index.do/3", "http://www.tv-links.co.uk/index.do/4", "http://www.tv-links.co.uk/index.do/5",]
        except Exception, e:
            traceback.print_exc(file=sys.stdout)
            dialog = xbmcgui.Dialog()
            dialog.ok("Error", "Error initializing script.\n\nReason:\n"+str(e))
    def get_list(self, url):
        try:
            self.list = {}
            sock = urllib.urlopen(url)
            htmlSource = sock.read()
            sock.close()
            reCAT = re.compile('<div class="ctr"><em id="letter">(.+?)</em></div>\n\s+</div>\n\s+</div>\n\s+</div>\n\s+<ul>(.+?)</ul>', re.DOTALL)
            reLIST = re.compile('<a href="/listings/(.+?)">(.+?)</a>', re.DOTALL)
            list = {}
            for i in reCAT.finditer(htmlSource):
                links = {}
                for x in reLIST.finditer(i.group(2)):
                    links[x.group(2)] = 'http://www.tv-links.co.uk/listings/' + x.group(1)
                list[i.group(1)] = links
            return list
        except Exception, e:
            traceback.print_exc(file=sys.stdout)
            dialog = xbmcgui.Dialog()
            dialog.ok("Error", "Playlist could not be opened.\n\nReason:\n"+str(e))

    def get_eps(self, url):
        try:
            self.list = {}
            self.morder = {}
            sock = urllib.urlopen(url)
            htmlSource = sock.read()
            sock.close()
            reEP = re.compile('<h4>(.+?)</h4>\n\s+<table cellspacing="0" cellpadding="2" border="0">(.+?)</table>', re.DOTALL)
            reSINGEP = re.compile('<tr>\n\s+<td>\n\s+(.+?)\s\n\s+</td>\n\s+<td>(.+?)</td>.+?</tr>', re.DOTALL)
            reSINGEPNAME = re.compile('<a target="_blank" href="(.+?)" onclick=".+?">(.+?)</a>', re.DOTALL)
            rePART = re.compile('^Part \d', re.DOTALL)
            last = "";
            for i in reEP.finditer(htmlSource):
                links = {}
                a = 0
                order = {}
                for x in reSINGEP.finditer(i.group(2)):
                    for y in reSINGEPNAME.finditer(x.group(2)):
                        name = y.group(2)
                        if rePART.search(name):
                            name = last+" "+name
                        else:
                            last = y.group(2)
                        order[a] = x.group(1)+" "+name
                        a = a+1
                        links[x.group(1)+" "+name] = 'http://www.tv-links.co.uk'+y.group(1)
                self.list[i.group(1)] = links
                self.morder[i.group(1)] = order
        except Exception, e:
                traceback.print_exc(file=sys.stdout)
                dialog = xbmcgui.Dialog()
                dialog.ok("Error", "Unable to look up episodes.\n\nReason:\n"+str(e))

    def addLink(self,name,url):
        listitem=xbmcgui.ListItem( name )
        if len(name)<20:
                name=name+"                           "
        liz=xbmcgui.ListItem(name)
        ok=xbmcplugin.addDirectoryItem(handle=self.handle,url=url,listitem=liz)

    def addDir(self,name,url,code,letter=" "):
        #url = "%s?genre=%d&title=%s&mode=%d&quality=%d" % ( sys.argv[ 0 ], genre[ 0 ], genre[ 1 ], 0, 2, )
        u=sys.argv[0]+"?code="+str(code)+"&url="+urllib.quote(url)+"&letter="+letter+"/"
        if len(name)<20:
                name=name+"                           "
        liz=xbmcgui.ListItem(name)
        xbmcplugin.addDirectoryItem(handle=self.handle,url=u,listitem=liz,isFolder=True)
        
    def get_link(self, url):
        link = ""
        try:
            sock = urllib.urlopen(url)
            htmlSource = sock.read()
            sock.close()
            reDIVX = re.compile('http://www([0-9]?)\.tv-links\.co\.uk/video/(.+?)\.divx', re.DOTALL)
            reFLV = re.compile('videoFile: \'(.+?)\'', re.DOTALL)
            reSWF = re.compile('<embed type="application/x-shockwave-flash" src="(.+?)"', re.DOTALL)
            divx = reDIVX.search(htmlSource)
            flv = reFLV.search(htmlSource)
            swf = reSWF.search(htmlSource)
            if divx:
                link = "http://www2.tv-links.co.uk/video/"+divx.group(2)+".divx"
            elif flv:
                link = flv.group(1)
            elif swf:
                link = swf.group(1)
            mySocket = socket.socket ( socket.AF_INET, socket.SOCK_STREAM )
            mySocket.connect ( ( 'www2.tv-links.co.uk', 80 ) )
            mySocket.send ( "GET "+link+" HTTP/1.1\r\nHost: www2.tv-links.co.uk\r\nUser-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.4) Gecko/20070515 Firefox/2.0.0.4\r\nAccept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5\r\nAccept-Language: en-us,en;q=0.5\r\nAccept-Encoding: gzip,deflate\r\nAccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7\r\nKeep-Alive: 300\r\nConnection: keep-alive\r\n\r\n" )
            htmlSource = mySocket.recv ( 1000 )
            mySocket.close()
            reLOC = re.compile("Location: (.+?)\r\n", re.DOTALL)
            LOC = reLOC.search(htmlSource)
            if LOC:
                link = LOC.group(1)
            if swf:
                reGUBA = re.compile('http://www\.guba\.com/f/root\.swf\?isEmbeddedPlayer=false&bid=(.+?)$', re.DOTALL)
                reDM = re.compile('http%3A%2F%2Fwww\.dailymotion\.com%2Fget%2F14%2F320x240%2Fflv%2F(.+?)%3Fkey%3D(.+?)&prev', re.DOTALL)
                reGOOGLE = re.compile('http://video\.google\.com/googleplayer\.swf\?.+?%3Fversion%3D(.+?)%26secureurl%3D(.+?)%26', re.DOTALL)
                GUBA = reGUBA.search(link)
                DM = reDM.search(link)
                GOOGLE = reGOOGLE.search(link)
                if GUBA:
                    resubGUBA = re.compile('^(\d).+?$', re.DOTALL)
                    subGUBA = resubGUBA.search(GUBA.group(1))
                    num = int(subGUBA.group(1)) - 1
                    link = "http://free.guba.com/download/flash/1/"+str(num)+"/"+GUBA.group(1)+"/"
                elif DM:
                    link = "http://www.dailymotion.com/get/14/320x240/flv/"+DM.group(1)+"?key="+DM.group(2)+""
                elif GOOGLE:
                    link = "http://vp.video.google.com/videodownload?version="+GOOGLE.group(1)+"&secureurl="+GOOGLE.group(2)
        except Exception, e:
                dialog = xbmcgui.Dialog()
                dialog.ok("Error", "Playlist could not be opened.\n\nReason:\n"+str(e))
        return link

    def onControl(self, code, url,letter=''):
        try:
            if code == -1:
                for i in range(len(self.Cats)):
                    self.addDir(self.Cats[i],self.Links[i],0)
            if code == 0:
                list=self.get_list(url)
                for x in sorted(list):
                        if (len(x)>0):
                            for y in list[x]:
                                self.addDir(y,list[x][y],1)
            if code == 1:
                self.get_eps(url)
                for y in sorted(self.list):
                    self.addDir(y,url,2,y)
            if code == 2:
                self.get_eps(url)
                for z in self.morder[letter]:
                    name=self.morder[letter][z]
                    link=self.get_link(self.list[letter][self.morder[letter][z]])
                    self.addLink(name,link)
                    #self.addDir(name,link,4,name)
        except Exception, e:
                traceback.print_exc(file=sys.stdout)
                dialog = xbmcgui.Dialog()
                dialog.ok("Error", "Error in onControl.\n\nReason:\n"+str(e))

    def run(self):
        try:
            self.handle=int(sys.argv[1])
            paramstring=sys.argv[2]
            if len(paramstring)<=2:
                self.onControl(-1,"")
            else:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                    params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                    splitparams={}
                    splitparams=pairsofparams[i].split('=')
                    if (len(splitparams))==2:
                        param[splitparams[0]]=splitparams[1]
                code=int(param['code'])
                url=urllib.unquote_plus(param['url'])
                letter=param['letter']
                self.onControl(code,url,letter)
        except Exception, e:
                traceback.print_exc(file=sys.stdout)
                dialog = xbmcgui.Dialog()
                dialog.ok("Error", "Error running script.\n\nReason:\n"+str(e))

tvl=TVLink()
tvl.run()
xbmcplugin.endOfDirectory(int(sys.argv[1]))