import os
import shutil

base_path = os.getcwd().replace( ";", "" )
base_cache_path = "q:\\UserData\\Thumbnails\\Video"
thumb_folder = os.path.join( base_path, "thumbs" )

def copy_thumbs( paths ):
    for path in paths:
        thumb = xbmc.getThumbName( path.replace( "\r\n", "" ).replace( "\r", "" ).replace( "\n", "" ) )
        cached_thumb = os.path.join( base_cache_path, thumb )
        finished_thumb = "%s.tbn" % os.path.join( thumb_folder, os.path.splitext( os.path.split( path.replace( "\n", "" ) )[ 1 ] )[ 0 ] )
        try:
            shutil.copy( cached_thumb, finished_thumb )
            print "Copied %s" % cached_thumb
            print "To %s" % finished_thumb
        except:
            print "***Failed to copy %s" % cached_thumb
            print "***To %s" % finished_thumb
        print "-"*79

def read_path_file():
    file_object = open( os.path.join( base_path, "path_file.txt" ), "r" )
    paths = file_object.readlines()
    file_object.close()
    return paths


if ( __name__ == "__main__" ):
    paths = read_path_file()
    copy_thumbs( paths )
    