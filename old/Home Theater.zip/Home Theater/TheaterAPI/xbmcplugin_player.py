"""
    Player Module:
    - plays # of optional coming attraction videos
    - plays # of random trailers
    - plays # of optional feature presentation videos
    - plays selected video
    - plays # of optional end of presentation videos
"""

import xbmc
# set our title
g_title = unicode( xbmc.getInfoLabel( "ListItem.Title" ), "utf-8" )
# set our studio (only works if the user is using the video library)
g_studio = unicode( xbmc.getInfoLabel( "ListItem.Studio" ), "utf-8" )
# set our director (only works if the user is using the video library)
g_director = unicode( xbmc.getInfoLabel( "ListItem.Director" ), "utf-8" )
# set our genre (only works if the user is using the video library)
g_genre = unicode( xbmc.getInfoLabel( "ListItem.Genre" ), "utf-8" )
# set our rating (only works if the user is using the video library)
g_mpaa_rating = xbmc.getInfoLabel( "ListItem.MPAA" )
# set our thumbnail
g_thumbnail = xbmc.getInfoImage( "ListItem.Thumb" )
# set our plotoutline
g_plotoutline = unicode( xbmc.getInfoLabel( "ListItem.PlotOutline" ), "utf-8" )
# set our year
g_year = 0
if ( xbmc.getInfoLabel( "ListItem.Year" ) ):
    g_year = int( xbmc.getInfoLabel( "ListItem.Year" ) )
# set our rating
g_rating = 0.0
if ( xbmc.getInfoLabel( "ListItem.Rating" ) ):
    g_rating = float( xbmc.getInfoLabel( "ListItem.Rating" ) )

# create the progress dialog (we do it here so there is minimal delay with nothing displayed)
import xbmcgui
import sys
pDialog = xbmcgui.DialogProgress()
pDialog.create( sys.modules[ "__main__" ].__plugin__, xbmc.getLocalizedString( 30500 )  )

# main imports
import os
import xbmcplugin

from random import randrange
from urllib import unquote_plus

from pysqlite2 import dbapi2 as sqlite


class _Info:
    def __init__( self, *args, **kwargs ):
        self.__dict__.update( kwargs )


class Trivia( xbmcgui.WindowXML ):
    import threading
    # special action codes
    ACTION_NEXT_SLIDE = ( 7, )
    ACTION_EXIT_SCRIPT = ( 9, 10, )

    def __init__( self, *args, **kwargs ):
        xbmcgui.WindowXML.__init__( self, *args, **kwargs )
        self.global_timer = None
        self.slide_timer = None
        self.slide_time = kwargs[ "trivia_slide_time" ]
        self.trivia_end_image = kwargs[ "trivia_end_image" ]
        self.trivia_end_music = kwargs[ "trivia_end_music" ]
        self._get_slides( kwargs[ "trivia_path" ] )
        self._get_global_timer( kwargs[ "trivia_total_time" ] )
        xbmc.Player().play( kwargs[ "trivia_music" ] )

    def onInit( self ):
        self._next_slide()

    def _get_slides( self, slide_path ):
        try:
            self.slides = []
            # get the directory listing
            entries = xbmc.executehttpapi( "GetDirectory(%s)" % ( slide_path, ) ).split( "\n" )
            # initialize type variables
            questions = []
            clues = []
            answers = []
            # enumerate through our items list and add the items in ther proper order question, clue, answer
            for entry in entries:
                if ( entry.lower().endswith( ".jpg" ) ):
                    # fix path
                    file_path = self._clean_file_path( entry )
                    # clue?
                    if ( file_path.lower().endswith( "c.jpg" ) ):
                        clues += [ file_path ]
                    # answer?
                    elif ( file_path.lower().endswith( "a.jpg" ) ):
                        answers += [ file_path ]
                    # question
                    else:
                        questions += [ file_path ]
            print "questions:"
            print questions
            print
            print "clues:"
            print clues
            print
            print "answers:"
            print answers
            print
            
            for count, question in enumerate( questions ):
                if ( question.endswith( "b.jpg" ) ):
                    self.slides += [ answers[ count ] ]
                else:
                    self.slides += [ question ]
                if ( len( clues ) > count ):
                    self.slides += [ clues[ count ] ]
                if ( question.endswith( "b.jpg" ) ):
                    self.slides += [ question ]
                elif ( len( answers ) > count ):
                    self.slides += [ answers[ count ] ]
            print self.slides
            print
        except:
            # oops print error message
            print "ERROR: %s::%s (%d) - %s" % ( self.__class__.__name__, sys.exc_info()[ 2 ].tb_frame.f_code.co_name, sys.exc_info()[ 2 ].tb_lineno, sys.exc_info()[ 1 ], )
        self.image_count = 0

    def _clean_file_path( self, path ):
        try:
            # replace <li>
            path = path.replace( "<li>", "" )
            # remove slash at end
            if ( path.endswith( "/" ) or path.endswith( "\\" ) ):
                path = path[ : -1 ]
            # make it a unicode object
            path = unicode( path, "utf-8" )
        except:
            print "ERROR: %s::%s (%d) - %s" % ( self.__class__.__name__, sys.exc_info()[ 2 ].tb_frame.f_code.co_name, sys.exc_info()[ 2 ].tb_lineno, sys.exc_info()[ 1 ], )
        # return final rsult
        return path

    def _get_global_timer( self, trivia_time ):
        try:
            self.global_timer = self.threading.Timer( trivia_time * 60, self.exit_script,() )
            self.global_timer.start()
        except:
            print "ERROR: %s::%s (%d) - %s" % ( self.__class__.__name__, sys.exc_info()[ 2 ].tb_frame.f_code.co_name, sys.exc_info()[ 2 ].tb_lineno, sys.exc_info()[ 1 ], )

    def _get_slide_timer( self ):
        try:
            self.slide_timer = self.threading.Timer( self.slide_time, self._next_slide,() )
            self.slide_timer.start()
        except:
            print "ERROR: %s::%s (%d) - %s" % ( self.__class__.__name__, sys.exc_info()[ 2 ].tb_frame.f_code.co_name, sys.exc_info()[ 2 ].tb_lineno, sys.exc_info()[ 1 ], )

    def _next_slide( self ):
        try:
            print self.image_count, len(self.slides )
            if ( self.image_count == len( self.slides ) ):
                print "_next_slide", self.image_count, len(self.slides )
                self.exit_script()
            else:
                if ( self.slide_timer is not None ):
                    self.slide_timer.cancel()
                self.getControl( 100 ).setImage( self.slides[ self.image_count ] )
                print self.slides[ self.image_count ]
                self.image_count += 1
                self._get_slide_timer()
        except:
            print "ERROR: %s::%s (%d) - %s" % ( self.__class__.__name__, sys.exc_info()[ 2 ].tb_frame.f_code.co_name, sys.exc_info()[ 2 ].tb_lineno, sys.exc_info()[ 1 ], )

    def exit_script( self ):
        if ( self.global_timer is not None ):
            self.global_timer.cancel()
        if ( self.slide_timer is not None ):
            self.slide_timer.cancel()
        if ( self.trivia_end_image ):
            self.getControl( 100 ).setImage( self.trivia_end_image )
            if ( self.trivia_end_music ):
                xbmc.Player().play( self.trivia_end_music )
            xbmc.sleep( self.slide_time * 1000 )
        self.close()

    def onClick( self, controlId ):
        pass

    def onFocus( self, controlId ):
        pass

    def onAction( self, action ):
        try:
            if ( action in self.ACTION_EXIT_SCRIPT ):
                self.exit_script()
            elif ( action in self.ACTION_NEXT_SLIDE ):
                self._next_slide()
        except:
            pass


class Main:
    # base paths
    BASE_CACHE_PATH = os.path.join( "P:\\Thumbnails", "Video" )
    BASE_DATA_PATH = os.path.join( "T:\\script_data", sys.modules[ "__main__" ].__script__ )

    def __init__( self ):
        self._get_settings()
        self._parse_argv()
        # create the playlist
        playlist = self._create_playlist()
        # play the videos
        self._play_videos( playlist )

    def _get_settings( self ):
        self.settings = {}
        self.settings[ "limit_query" ] = xbmcplugin.getSetting( "limit_query" ) == "true"
        self.settings[ "newest_only" ] = xbmcplugin.getSetting( "newest_only" ) == "true"
        self.settings[ "rating" ] = int( xbmcplugin.getSetting( "rating" ) )
        self.settings[ "number_trailers" ] = int( xbmcplugin.getSetting( "number_trailers" ) )
        self.settings[ "quality" ] = int( xbmcplugin.getSetting( "quality" ) )
        self.settings[ "only_hd" ] = xbmcplugin.getSetting( "only_hd" ) == "true"
        ##self.settings[ "player_core" ] = ( xbmc.PLAYER_CORE_MPLAYER, xbmc.PLAYER_CORE_DVDPLAYER, )[ int( xbmcplugin.getSetting( "player_core" ) ) ]
        self.settings[ "trivia_path" ] = xbmcplugin.getSetting( "trivia_path" )
        self.settings[ "trivia_total_time" ] = ( 0, 5, 10, 15, 20, 25, 30, )[ int( xbmcplugin.getSetting( "trivia_total_time" ) ) ]
        self.settings[ "trivia_slide_time" ] = ( 10, 15, 20, 25, 30, 45, 60 )[ int( xbmcplugin.getSetting( "trivia_slide_time" ) ) ]
        self.settings[ "trivia_music" ] = xbmcplugin.getSetting( "trivia_music" )
        self.settings[ "trivia_end_image" ] = xbmcplugin.getSetting( "trivia_end_image" )
        self.settings[ "trivia_end_music" ] = xbmcplugin.getSetting( "trivia_end_music" )
        self.settings[ "coming_attraction_videos" ] = xbmcplugin.getSetting( "coming_attraction_videos" )
        self.settings[ "feature_presentation_videos" ] = xbmcplugin.getSetting( "feature_presentation_videos" )
        self.settings[ "end_presentation_videos" ] = xbmcplugin.getSetting( "end_presentation_videos" )

    def _parse_argv( self ):
        # call _Info() with our formatted argv to create the self.args object
        exec "self.args = _Info(%s)" % ( sys.argv[ 2 ][ 1 : ].replace( "&", ", " ), )
        # unquote path
        self.args.path = unquote_plus( self.args.path )

    def _create_playlist( self ):
        # create a video playlist
        playlist = xbmc.PlayList( xbmc.PLAYLIST_VIDEO )
        # clear any possible items
        playlist.clear()
        # if there is a trailer intro video add it
        if ( self.settings[ "coming_attraction_videos" ] ):
            # create our trailer record
            trailer = ( self.settings[ "coming_attraction_videos" ], os.path.splitext( os.path.basename( unicode( self.settings[ "coming_attraction_videos" ], "utf-8" ) ) )[ 0 ], "", self.settings[ "coming_attraction_videos" ], "", "", "", "", "", 0, "", "", "", "", "", "", "Coming Attractions Intro", 0.0, "", )
            # create the listitem and fill the infolabels
            listitem = self._get_listitem( trailer )
            # add our item to the playlist
            playlist.add( unicode( self.settings[ "coming_attraction_videos" ], "utf-8" ), listitem )
        # fetch our random trailers
        trailers = self._fetch_records()
        # enumerate through our list of trailers and add them to our playlist
        for trailer in trailers:
            # we need to select the proper trailer url
            url = self._get_trailer_url( eval( trailer[ 3 ] ) )
            # add a false rating
            trailer += ( 0.0, )
            # create the listitem and fill the infolabels
            listitem = self._get_listitem( trailer + ( "", ) )
            # add our item to the playlist
            playlist.add( url, listitem )
        # if there is a movie intro video add it
        if ( self.settings[ "feature_presentation_videos" ] ):
            # create our trailer record
            trailer = ( self.settings[ "feature_presentation_videos" ], os.path.splitext( os.path.basename( unicode( self.settings[ "feature_presentation_videos" ], "utf-8" ) ) )[ 0 ], "", self.settings[ "feature_presentation_videos" ], "", "", "", "", "", 0, "", "", "", "", "", "", "Feature Presentation Intro", 0.0, "", )
            # create the listitem and fill the infolabels
            listitem = self._get_listitem( trailer )
            # add our item to the playlist
            playlist.add( unicode( self.settings[ "feature_presentation_videos" ], "utf-8" ), listitem )
        # set the genre if missing
        genre = g_genre
        if ( not g_genre ):
            genre = "Feature Presentation"
        # add the selected video to our playlist
        trailer = ( sys.argv[ 0 ] + sys.argv[ 2 ], g_title, "", self.args.path, g_thumbnail, g_plotoutline, "", "", "", g_year, "", "", "", "", "", g_studio, genre, g_rating, g_director, )
        # create the listitem and fill the infolabels
        listitem = self._get_listitem( trailer )
        # add our item to the playlist
        playlist.add( self.args.path, listitem )
        # if there is a end of movie video add it
        if ( self.settings[ "end_presentation_videos" ] ):
            # create our trailer record
            trailer = ( self.settings[ "end_presentation_videos" ], os.path.splitext( os.path.basename( unicode( self.settings[ "end_presentation_videos" ], "utf-8" ) ) )[ 0 ], "", self.settings[ "end_presentation_videos" ], "", "", "", 0, "", 0, "", "", "", "", "", "", "End of Feature Presentation", 0.0, "", )
            # create the listitem and fill the infolabels
            listitem = self._get_listitem( trailer )
            # add our item to the playlist
            playlist.add( unicode( self.settings[ "end_presentation_videos" ], "utf-8" ), listitem )
        return playlist

    def _play_videos( self, playlist ):
        pDialog.close()
        if ( playlist and not pDialog.iscanceled() ):
            # if trive path an time play the trivia slides
            if ( self.settings[ "trivia_path" ] and self.settings[ "trivia_total_time" ] ):
                ui = Trivia( "plugin-%s-trivia.xml" % ( sys.modules[ "__main__" ].__plugin__.replace( " ", "_" ), ), sys.modules[ "__main__" ].BASE_RESOURCE_PATH, "default", False, trivia_path=self.settings[ "trivia_path" ], trivia_total_time=self.settings[ "trivia_total_time" ], trivia_slide_time=self.settings[ "trivia_slide_time" ], trivia_music=self.settings[ "trivia_music" ], trivia_end_image=self.settings[ "trivia_end_image" ], trivia_end_music=self.settings[ "trivia_end_music" ] )
                ui.doModal()
                del ui
            # TODO: enable player core when XBMC supports it for playlists
            xbmc.Player().play( playlist )# self.settings[ "player_core" ]

    def _fetch_records( self ):
        try:
            records = Records()
            # select only trailers with valid trailer urls
            sql = """
                        SELECT movies.*, studios.studio, genres.genre  
                        FROM movies, genres, genre_link_movie, studios, studio_link_movie 
                        WHERE movies.trailer_urls IS NOT NULL 
                        AND movies.trailer_urls!='[]' 
                        %s
                        %s
                        AND genre_link_movie.idMovie=movies.idMovie 
                        AND genre_link_movie.idGenre=genres.idGenre 
                        AND studio_link_movie.idMovie=movies.idMovie 
                        AND studio_link_movie.idStudio=studios.idStudio 
                        %s
                        ORDER BY RANDOM() 
                        LIMIT %d;
                    """
            # mpaa ratings
            mpaa_ratings = [ "G", "PG", "PG-13", "R", "NC-17" ]
            rating_sql = ""
            # if the user set a valid rating add all up to the selection
            if ( self.settings[ "rating" ] < len( mpaa_ratings ) ):
                user_rating = mpaa_ratings[ self.settings[ "rating" ] ]
                rating_sql = "AND ("
                # enumerate through mpaa ratings and add the selected ones to our sql statement
                for rating in mpaa_ratings:
                    rating_sql += "rating='%s' OR " % ( rating, )
                    # if we found the users choice, we're finished
                    if ( rating == user_rating ): break
                # fix the sql statement
                rating_sql = rating_sql[ : -4 ] + ") "
            hd_sql = ( "", "AND (movies.trailer_urls LIKE '%720p.mov%' OR movies.trailer_urls LIKE '%1080p.mov%')", )[ self.settings[ "only_hd" ] and ( self.settings[ "quality" ] > 3 ) ]
            genre_sql = ""
            if ( self.settings[ "newest_only" ] ):
                genre_sql = "AND genres.genre='Newest'\n"
            # if the use sets limit query limit our search to the genre and rating of the movie
            if ( self.settings[ "limit_query" ] ):
                # genre limit
                ##movie_genres = unicode( xbmc.getInfoLabel( "ListItem.Genre" ), "utf-8" ).split( "/" )
                if ( not genre_sql ):
                    movie_genres = g_genre.split( "/" )
                    if ( movie_genres[ 0 ] != "" ):
                        genre_sql = "AND ("
                        for genre in movie_genres:
                            genre = genre.strip().replace( "Sci-Fi", "Science Fiction" )
                            if ( genre == "Action" or genre == "Adventure" ):
                                genre = "Action and Adventure"
                            # fix certain genres
                            genre_sql += "genres.genre='%s' OR " % ( genre, )
                        # fix the sql statement
                        genre_sql = genre_sql[ : -4 ] + ") "
                # rating limit TODO: decide if this should override the set rating limit
                ##movie_rating = xbmc.getInfoLabel( "ListItem.MPAA" ).split( " " )
                movie_rating = g_mpaa_rating.split( " " )
                if ( len( movie_rating ) > 1 ):
                    if ( movie_rating[ 1 ] in mpaa_ratings ):
                        rating_sql = "AND ("
                        for rating in mpaa_ratings:
                            rating_sql += "rating='%s' OR " % ( rating, )
                            # if we found the users choice, we're finished
                            if ( rating == movie_rating[ 1 ] ): break
                        # fix the sql statement
                        rating_sql = rating_sql[ : -4 ] + ") "
            # fetch our trailers
            result = records.fetch( sql % ( hd_sql, rating_sql, genre_sql, self.settings[ "number_trailers" ], ) )
            records.close()
        except:
            # oops print error message
            print "ERROR: %s::%s (%d) - %s" % ( self.__class__.__name__, sys.exc_info()[ 2 ].tb_frame.f_code.co_name, sys.exc_info()[ 2 ].tb_lineno, sys.exc_info()[ 1 ], )
            result = []
        return result

    def _get_listitem( self, trailer ):
        # check for a valid thumbnail
        thumbnail = ""
        if ( trailer[ 4 ] and trailer[ 4 ] is not None ):
            thumbnail = xbmc.translatePath( os.path.join( self.BASE_DATA_PATH, ".cache", trailer[ 4 ][ 0 ], trailer[ 4 ] ) )
        else:
            thumbnail = self._get_thumbnail( trailer[ 3 ], trailer[ 0 ] )
        # set the default icon
        icon = "DefaultVideo.png"
        # only need to add label, icon and thumbnail, setInfo() and addSortMethod() takes care of label2
        listitem = xbmcgui.ListItem( trailer[ 1 ], iconImage=icon, thumbnailImage=thumbnail )
        # add the different infolabels we want to sort by
        listitem.setInfo( type="Video", infoLabels={ "Title": trailer[ 1 ], "year": trailer[ 9 ], "Studio": trailer[ 15 ], "Genre": trailer[ 16 ], "Plot": trailer[ 5 ], "PlotOutline": trailer[ 5 ], "Rating": trailer[ 17 ], "Director": trailer[ 18 ] } )
        return listitem

    def _get_thumbnail( self, item, url ):
        # All these steps are necessary for the differnt caching methods of XBMC
        # make the proper cache filename and path so duplicate caching is unnecessary
        filename = xbmc.getCacheThumbName( item )
        thumbnail = xbmc.translatePath( os.path.join( self.BASE_CACHE_PATH, filename[ 0 ], filename ) )
        # if the cached thumbnail does not exist create the thumbnail based on url
        if ( not os.path.isfile( thumbnail ) ):
            filename = xbmc.getCacheThumbName( url )
            thumbnail = xbmc.translatePath( os.path.join( self.BASE_CACHE_PATH, filename[ 0 ], filename ) )
            # if the cached thumbnail does not exist create the thumbnail based on filepath.tbn
            if ( not os.path.isfile( thumbnail ) ):
                # create filepath to a local tbn file
                thumbnail = os.path.splitext( item )[ 0 ] + ".tbn"
                # if there is no local tbn file use a default
                if ( not os.path.isfile( thumbnail ) or thumbnail.startswith( "smb://" ) ):
                    thumbnail = ""
        return thumbnail

    def _get_trailer_url( self, trailer_urls ):
        # pick a random url (only applies to multiple urls)
        r = randrange( len( trailer_urls ) )
        # get the preferred quality
        qualities = [ "Low", "Medium", "High", "480p", "720p", "1080p" ]
        url = ""
        # get intial choice
        choice = ( self.settings[ "quality" ], len( trailer_urls[ r ] ) - 1, )[ self.settings[ "quality" ] >= len( trailer_urls[ r ] ) ]
        # if quality is non progressive
        if ( self.settings[ "quality" ] <= 2 ):
            # select the correct non progressive trailer
            while ( trailer_urls[ r ][ choice ].endswith( "p.mov" ) and choice != -1 ): choice -= 1
        # quality is progressive
        else:
            # select the proper progressive quality
            quality = ( "480p", "720p", "1080p", )[ self.settings[ "quality" ] - 3 ]
            # select the correct progressive trailer
            while ( quality not in trailer_urls[ r ][ choice ] and trailer_urls[ r ][ choice ].endswith( "p.mov" ) and choice != -1 ): choice -= 1
        # if there was a valid trailer set it
        if ( choice >= 0 ):
            url = trailer_urls[ r ][ choice ]
        return url


class Records:
    # base paths
    BASE_DATABASE_PATH = sys.modules[ "__main__" ].BASE_DATABASE_PATH

    def __init__( self, *args, **kwargs ):
        self.connect()

    def connect( self ):
        self.db = sqlite.connect( self.BASE_DATABASE_PATH )
        self.cursor = self.db.cursor()
    
    def close( self ):
        self.db.close()
    
    def fetch( self, sql, params=None ):
        try:
            if ( params is not None ): self.cursor.execute( sql, params )
            else: self.cursor.execute( sql )
            retval = self.cursor.fetchall()
        except:
            retval = None
        return retval
