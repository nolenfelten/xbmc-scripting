import xbmcgui, os
import traceback

base_path = os.getcwd().replace(";","")

class windowOverlay(xbmcgui.Window):
    def __init__(self):
        self.effect = False
        self.pictures = []
        self.pictures += [ xbmcgui.ControlImage( 50,100,500,400,os.path.join(base_path,"galaxy6.png"),aspectRatio=1) ]
        self.pictures += [ xbmcgui.ControlImage( 50,100,500,400,os.path.join(base_path,"galaxy7.png"),aspectRatio=1) ]
        self.label = xbmcgui.ControlLabel(50,50,300,30,"")
        for picture in self.pictures:
            self.addControl( picture )
        self.pictures[1].setColorDiffuse("00FFFFFF" )
        self.pictures[0].setColorDiffuse("FFFFFFFF" )
        self.addControl( self.label )
        
    def fade( self ):
        self.effect = not self.effect
        self.label.setLabel(( "Fade in then fade out","Fade in/out same time", )[self.effect])
        self.pictures[1].setColorDiffuse("00FFFFFF" )
        self.pictures[0].setColorDiffuse("FFFFFFFF" )
        xbmc.sleep(1000)
        try:
            if ( self.effect ):
                for i in range( 256 ):
                    self.pictures[1].setColorDiffuse("%02xFFFFFF" % i )
                    self.pictures[0].setColorDiffuse("%02xFFFFFF" % ( 255 - i, ) )
                    xbmc.sleep(10)
            else:
                for i in range( 256 ):
                    self.pictures[1].setColorDiffuse("%02xFFFFFF" % i )
                    xbmc.sleep(10)
                for i in range( 256 ):
                    self.pictures[0].setColorDiffuse("%02xFFFFFF" % (255 - i, ) )
                    xbmc.sleep(10)
        except: traceback.print_exc()
                

    def onAction( self, action ):
        if action == 9 or action == 10: self.close()
        else: self.fade()

        
win = windowOverlay()
win.doModal()
del win


        