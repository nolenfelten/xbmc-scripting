"""
    Plugin for streaming music content from the internet
"""

# main imports
import sys
import os
import xbmc
import xbmcgui
import xbmcplugin

import re
import urllib


# plugin constants
__plugin__ = "MPlayer Samples"
__author__ = "nuka1195"
__url__ = "http://code.google.com/p/xbmc-addons/"
__svn_url__ = "http://xbmc-addons.googlecode.com/svn/trunk/plugins/videos/MPlayer%20Samples"
__credits__ = "Team XBMC"
__version__ = "1.0"


class _Info:
    def __init__( self, *args, **kwargs ):
        self.__dict__.update( kwargs )


class _Parser:
    """
        Parses an html document for category links
    """
    def __init__( self, htmlSource ):
        # initialize our content lists
        self.directories = []
        self.videos = []
        # get the list
        self._get_items( htmlSource )

    def _get_items( self, htmlSource ):
        # parse source for items
        items = re.findall( '<tr><td class="n"><a href="([^"]*)">[^<]*</a>/?</td><td class="m">([^<]*)</td><td class="s">([^<]*)</td><td class="t">([^<]*)<', htmlSource )
        # enumerate thru items and set directories and videos
        for item in items:
            if ( item[ 3 ] == "Directory" ):
                if ( item[ 0 ] != "../" ):
                    self.directories += [ item ]
            elif ( os.path.splitext( item[ 0 ] )[ 1 ] and os.path.splitext( item[ 0 ] )[ 1 ] in xbmc.getSupportedMedia( "video" ) ):
                print os.path.splitext( item[ 0 ] )[ 1 ]
                self.videos += [ item ]
        

class Main:
    # base urls
    BASE_URL = "http://samples.mplayerhq.hu/"

    # base paths
    BASE_PATH = os.getcwd().replace( ";", "" )
    BASE_DATA_PATH = os.path.join( "T:\\plugin_data", __plugin__ )
    BASE_SOURCE_PATH = os.path.join( BASE_DATA_PATH, "screamer.html" )
    #BASE_SKIN_THUMBNAIL_PATH = os.path.join( "Q:\\skin", xbmc.getSkinDir(), "media", __plugin__ )
    BASE_PLUGIN_THUMBNAIL_PATH = os.path.join( BASE_PATH, "thumbnails" )

    def __init__( self ):
        # parse our argv
        self._parse_argv()
        # get the sites assets
        ok = self.get_items()
        # send notification we're finished, successfully or unsuccessfully
        xbmcplugin.endOfDirectory( handle=int( sys.argv[ 1 ] ), succeeded=ok )

    def _parse_argv( self ):
        # call _Info() with our formatted argv to create the self.args object
        if ( sys.argv[ 2 ] ):
            exec "self.args = _Info(%s)" % ( sys.argv[ 2 ][ 1 : ].replace( "&", ", " ).replace( "\\u0027", "'" ).replace( "\\u0022", '"' ).replace( "\\u0026", "&" ), )
        else:
            self.args = _Info( url=self.BASE_URL )

    def get_items( self ):
        ok = False
        # fetch the web page
        htmlSource = self._get_html_source( self.args.url )
        # if we were succesfule, parse for videos and directories
        if ( htmlSource is not None ):
            directories, videos = self.parse_html_source( htmlSource )
            # if directories were found, add them
            if ( directories ):
                ok = self._fill_media_list_directories( directories )
            # if videos were found, add them
            if ( videos ):
                ok = self._fill_media_list_videos( videos )
        return ok

    def _get_html_source( self, url ):
        try:
            # open url
            usock = urllib.urlopen( url )
            # read source
            htmlSource = usock.read()
            # close socket
            usock.close()
        except:
            # oops print error message
            print "ERROR: %s::%s (%d) - %s" % ( self.__class__.__name__, sys.exc_info()[ 2 ].tb_frame.f_code.co_name, sys.exc_info()[ 2 ].tb_lineno, sys.exc_info()[ 1 ], )
            htmlSource = None
        return htmlSource

    def parse_html_source( self, htmlSource ):
        # Parse htmlSource for directories and videos
        parser = _Parser( htmlSource )
        return parser.directories, parser.videos

    def _fill_media_list_directories( self, directories ):
        try:
            ok = True
            # enumerate through the list of directories and add the item to the media list
            for category in directories:
                url = "%s?url=%s" % ( sys.argv[ 0 ], repr( self.args.url + category[ 0 ] ) )
                # set the default icon
                icon = "DefaultFolder.png"
                # only need to add label and thumbnail, setInfo() and addSortMethod() takes care of label2
                listitem=xbmcgui.ListItem( category[ 0 ], iconImage=icon )
                # add the item to the media list
                ok = xbmcplugin.addDirectoryItem( handle=int( sys.argv[ 1 ] ), url=url, listitem=listitem, isFolder=True, totalItems=len( directories ) )
                # if user cancels, call raise to exit loop
                if ( not ok ): raise
        except:
            # user cancelled dialog or an error occurred
            print "ERROR: %s::%s (%d) - %s" % ( self.__class__.__name__, sys.exc_info()[ 2 ].tb_frame.f_code.co_name, sys.exc_info()[ 2 ].tb_lineno, sys.exc_info()[ 1 ], )
            ok = False
        return ok

    def _fill_media_list_videos( self, videos ):
        try:
            ok = True
            # enumerate through the list of directories and add the item to the media list
            for video in videos:
                # check for a valid custom thumbnail for the current category
                icon = "defaultAudio.png"
                # only need to add label and icon, setInfo() and addSortMethod() takes care of label2
                listitem=xbmcgui.ListItem( video[ 0 ], iconImage=icon )
                # add the item to the media list
                ok = xbmcplugin.addDirectoryItem( handle=int( sys.argv[ 1 ] ), url=self.args.url + video[ 0 ], listitem=listitem, isFolder=False, totalItems=len( videos ) )
                # if user cancels, call raise to exit loop
                if ( not ok ): raise
        except:
            # user cancelled dialog or an error occurred
            print "ERROR: %s::%s (%d) - %s" % ( self.__class__.__name__, sys.exc_info()[ 2 ].tb_frame.f_code.co_name, sys.exc_info()[ 2 ].tb_lineno, sys.exc_info()[ 1 ], )
            ok = False
        return ok

    def _get_thumbnail( self, title ):
        # create the full thumbnail path for skins directory
        thumbnail = xbmc.translatePath( os.path.join( self.BASE_SKIN_THUMBNAIL_PATH, title.replace( " ", "-" ).lower() + ".tbn" ) )
        # use a plugin custom thumbnail if a custom skin thumbnail does not exists
        if ( not os.path.isfile( thumbnail ) ):
            # create the full thumbnail path for plugin directory
            thumbnail = xbmc.translatePath( os.path.join( self.BASE_PLUGIN_THUMBNAIL_PATH, title.replace( " ", "-" ).lower() + ".tbn" ) )
            # use a default thumbnail if a custom thumbnail does not exists
            if ( not os.path.isfile( thumbnail ) ):
                thumbnail = ""
        return thumbnail


if ( __name__ == "__main__" ):
    Main()
