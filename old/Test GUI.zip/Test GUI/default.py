import sys
import os
import xbmcgui
import xbmc

class GUI( xbmcgui.WindowXMLDialog ):
    """ Settings module: used for changing settings """
    def __init__( self, *args, **kwargs ):
        # do any pre control functions here
        self.doModal()

    def onInit( self ):
        # this is where you can do things on controls before they become visible
        
    def _close_dialog( self ):
        self.close()

    def onClick( self, controlId ):
        # required
        pass

    def onFocus( self, controlId ):
        # required
        pass

    def onAction( self, action ):
        # required
        if ( action == 9 or action == 10 ):
            self._close_dialog()

if ( __name__ == "__main__" ):
    # 1. the xml's filename    2. directory the skins folder is in     3. The name of the default skin  4. optional True/False bool to force fallback
    GUI( "XML_Name.xml", os.getcwd().replace( ";", "" ), "Default" )
