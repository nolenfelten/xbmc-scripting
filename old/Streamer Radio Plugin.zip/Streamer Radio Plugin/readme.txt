Streamer Radio is a Internet Radio player for Xbmc Media Center. Using presets maintained regularly. 
When there is no xbox nearby, please use Screamer Radio (a very nice player for PC). 
Huge thanks for letting me use the presetlist from it. See www.screamer-radio.com
