import urllib,re,sys,socket
import xbmcplugin,xbmcgui
import htmllib

#[(url,catname)]
def getCategories(url):
        res=[]
        f=urllib.urlopen(url)
        a=f.read()
        f.close()
        #p=re.compile(r'<a href="\.(\?cat=\w*)".+?/> (\w*)')
        p=re.compile(r'<a href="(.*?)">(\w*)')
        match=p.findall(a)
        for url,name in match:
                res.append((url,name))
        return res

#[(url,show)]
def getShows(url):
        res=[]
        url = urllib.quote(url,':/')
        f=urllib.urlopen("http://powerflv.com/cache2/" + url)
        a=f.read()
        f.close()
        #p=re.compile(r'<a href=\"\.(\?.+?)" .+? \/> (.+?)</a><br />')
        p=re.compile(r'<a href="(.+?---.+?)"> *?(.+?)</a>')
        match=p.findall(a)
        for url,name in match:
                res.append((url,name))
        return res

#[seasonnames]
def getSeasons(url):
        res=[]
        f=urllib.urlopen("http://powerflv.com/cache2/" + url)
        a=f.read()
        f.close()
        p=re.compile(r'<h4.*?>(.+?)</h4>')
        match=p.findall(a)
        for a in match:
                res.append(a)
        return res

#[(url,name)]
def getShowSeason(url,parm):
        f=urllib.urlopen("http://powerflv.com/cache2/" + url)
        a=f.read()
        f.close()
        res=[]
        sect=re.compile(r"<h4.*?>"+re.escape(parm)+r"</h4>(.+?)</(h4|html)>",re.DOTALL)
        matches1=sect.findall(a)
        for sectionmatch in matches1:
                #p=re.compile(r"<a onclick=\"popscreen\(\'(.+?)\'.+?\/\> (.+?)</a><br />")
                p=re.compile(r"<a onclick=\"popscreen\(\'(.+?)\'\).+?\/\>(.+?)</a\><br />")
                match=p.findall(sectionmatch[0])
                for a in match:
                        res.append(a)
        return res

def getDivxFile(a):
        res=[]
        p=re.compile(r'<embed .+?src="(.+?video.stage6.com.+?)"')
        match=p.findall(a)
        for a in match:
                res.append(a)
        return res


def getPowerFLVVideos(a):
        urls=[]
        p=re.compile(r'http\:\/\/powerflv\.com\/powerflv4\.swf\?li\=(.+?)&')
        match=p.findall(a)
        for a in match:
                f=urllib.urlopen("http://powerflv.com/datamongster?li="+a)
                c=f.read()
                f.close()
                parameters=[]
                if c[0]=="&": c=c[1:-1]
                parms=c.split("&")
                parts=1
                for parm in parms:
                        splitparms=parm.split("=")
                        if splitparms[0]=="parts":
                                parts=int(splitparms[1])
                        else:
                                if parts>0:
                                        parts=parts-1
                                        urls.append(urllib.unquote_plus(splitparms[1]))
        return urls

def getYoutubeIFrame(a):
        res=[]
        esc=re.escape("<iframe src=\"http://youtube.com/watch?v=")
        p=re.compile(esc+'(.+?)"')
        match=p.findall(a)
        for b in match:
                #google now caches videos for us, very convenient for grabbing the url! does this work for all vids?
                res.append("http://cache.googlevideo.com/get_video?video_id="+b)
        return res


def getVideoParts(a):
        res=[]
        p=re.compile(r'<a href.*?\=.*?\"(play2\?.+?&part=[0-9]+?)"')
        match=p.findall(a)
        for a in match:
                res.append("http://powerflv.com/"+a)
        return res


def getGoogleVideo(a):
        p=re.compile(re.escape('<param name="movie" value="http://video.google.com/googleplayer.swf?&videoUrl=')+'(.+?)"')
        match=p.findall(a)
        res=[]
        for a in match:
                res.append(urllib.unquote_plus(a))
        return res

def getFreeFlashPlayer(a):
        res=[]
        p=re.compile(re.escape('<param name="movie" value="http://freeflashplayer.net/flvplayer.swf?url=')+'(.+?)&')
        match=p.findall(a)
        for a in match:
                res.append(urllib.unquote_plus(a))
        return res

def getGubaVideo(a):
        p=re.compile(re.escape('<embed src="http://www.guba.com')+'.+?\?.+?bid\=(.+?)[?|&|"]')
        GUBA = p.search(a)
        if GUBA:
                resubGUBA = re.compile('^(\d).+?$', re.DOTALL)
                subGUBA = resubGUBA.search(GUBA.group(1))
                num = int(subGUBA.group(1)) - 1
                link = "http://free.guba.com/download/flash/1/"+str(num)+"/"+GUBA.group(1)+"/"
                return [link]
        else:
                return []

def getTPSolution(a):
        res=[]
        p=re.compile(re.escape('<iframe src="http://www.tpsolution.net/fullscreen.php?video_id=')+'(.+?)"')
        match=p.findall(a)
        for id in match:
                f2=urllib.urlopen("http://www.tpsolution.net/video/"+id+".html")
                c2=f2.read()
                f2.close()
                p2=re.compile(re.escape('<param name="src" value="')+'(.+?)"')
                match2=p2.findall(c2)
                for vidurl in match2:
                        mySocket = socket.socket ( socket.AF_INET, socket.SOCK_STREAM )
                        mySocket.connect ( ( 'www.tpsolution.net', 80 ) )
                        mySocket.send ( "GET "+vidurl+" HTTP/1.1\r\nHost: www.tpsolution.net\r\nUser-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.4) Gecko/20070515 Firefox/2.0.0.4\r\nAccept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5\r\nAccept-Language: en-us,en;q=0.5\r\nAccept-Encoding: gzip,deflate\r\nAccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7\r\nKeep-Alive: 300\r\nConnection: keep-alive\r\n\r\n" )
                        htmlSource = mySocket.recv ( 1000 )
                        mySocket.close()
                        reLOC = re.compile("Location: (.+?)(\r|\n)", re.DOTALL)
                        LOC = reLOC.search(htmlSource)
                        if LOC:
                                link = LOC.group(1)
                        res.append(link)
        return res
        
def getVeoh(a):
        res=[]
        p=re.compile(r'<iframe src="http\:\/\/www\.veoh\.com/.+?\.swf\?permalinkId=(.+?)&')
        match=p.findall(a)
        for a in match:
                f=urllib.urlopen("http://www.veoh.com/rest/video/"+str(a)+"/details")
                veo=f.read()
                comp=re.compile('fullPreviewHashPath="(.+?)"')
                for d in comp.findall(veo):
                        res.append(d)
        return res
        
def getVeohEmbed(a):
        res=[]
        p=re.compile(r'<param name="movie" value="http://www\.veoh\.com/videodetails\.swf\?permalinkId=(.+?)&player=videodetails&videoAutoPlay=1" />')
        match=p.findall(a)
        for a in match:
                f=urllib.urlopen("http://www.veoh.com/rest/video/"+str(a)+"/details")
                veo=f.read()
                comp=re.compile('fullPreviewHashPath="(.+?)"')
                for d in comp.findall(veo):
                        res.append(d)
        return res
        
def getSpikedHumour(a):
        res=[]
        p=re.compile(r'<iframe src="(.+?)"')
        match=p.findall(a)
        for a in match:
                f=urllib.urlopen(a)
                q=f.read()
                f.close()
                p=re.compile(r'<a href="(.+?)" target="_new"')
                match=p.findall(q)
                for q in match:
                        res.append(match)
        return res

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

def getAllVideos(a):
        res=[]
        res.extend(getVeoh(a))
        res.extend(getVeohEmbed(a))
        res.extend(getGubaVideo(a))
        res.extend(getFreeFlashPlayer(a))
        res.extend(getGoogleVideo(a))
        res.extend(getYoutubeIFrame(a))
        res.extend(getPowerFLVVideos(a))
        res.extend(getDivxFile(a))
        res.extend(getTPSolution(a))
        res.extend(getSpikedHumour(a))
        return res


def getVidLinks(url):
        f=urllib.urlopen(url)
        a=f.read()
        f.close()
        parts=getVideoParts(a)
        if len(parts)<=1:
                return getAllVideos(a)
        else:
                res=[]        
                for part in parts:
                        f=urllib.urlopen(part)
                        c=f.read()
                        f.close()
                        res.extend(getAllVideos(c))
                return res
def addLink(name,url):
        #print name
        #print url
        #print "--"
        ok=True
        thumbnail_url = url.split( "thumbnailUrl=" )[ -1 ]
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=thumbnail_url)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,mode):
        u=sys.argv[0]+"?url="+urllib.quote(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        name = cleanText( name )
        pattern = " *\(([0-9]{4})\)"
        date = re.findall( pattern, name )
        year = 0
        # since this is a folder the year will not show for label2, but we can still sort by year
        if ( len( date ) ):
            year = int( date[ 0 ] )
        liz=xbmcgui.ListItem(name)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Year": year } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def cleanText(s):
        p = htmllib.HTMLParser(None)
        p.save_bgn()
        p.feed(s)
        return p.save_end()

def showMainMenu():
        cats=getCategories("http://powerflv.com/cache2/")
        for url,name in cats:
                addDir(name,url,1)

def showShows(url):
        shows=getShows(url)
        for url,name in shows:
                addDir(name,url,2)

def showSeasons(url):
        seasons=getSeasons(url)
        for name in seasons:
                addDir(name,url,3)

def showEpisodes(url,name):
        episodes=getShowSeason(url,name)
        for url,name in episodes:
                addDir(name,url,4)

def showVidLinks(url):
        vidLinks=getVidLinks(url)
        i=0
        for url in vidLinks:
                i=i+1
                addLink("Part "+str(i),url)



params=get_params()
url=None
name=None
mode=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
if mode==None or url==None or len(url)<1:
        print "Main Menu"
        showMainMenu()
elif mode==1:
        print "show Shows: "+url
        showShows(url)
elif mode==2:
        print "show seasons: "+url
        showSeasons(url)
elif mode==3:
        print "show eps: "+url+" - "+name
        showEpisodes(url,name)
elif mode==4:
        print "show vidlinks: "+url
        showVidLinks(url)
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_YEAR )
xbmcplugin.endOfDirectory(int(sys.argv[1]))
