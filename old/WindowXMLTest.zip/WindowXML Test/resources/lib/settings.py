"""
Settings module

Nuka1195
"""

import sys
import os
import xbmc
import xbmcgui
#import traceback

import utilities
import chooser

_ = sys.modules[ "__main__" ].__language__
__scriptname__ = sys.modules[ "__main__" ].__scriptname__
__version__ = sys.modules[ "__main__" ].__version__


class GUI( xbmcgui.WindowXMLDialog ):
    """ Settings module: used for changing settings """
    def __init__( self, *args, **kwargs ):
        self.genres = kwargs[ "genres" ]
        self.skin = kwargs[ "skin" ]
        self.chooser = None

    def onInit( self ):
        self._get_settings()
        self._set_labels()
        self._set_functions()
        self._setup_special()
        self._set_restart_required()
        self._set_controls_values()

    def _get_settings( self ):
        """ reads settings """
        self.settings = utilities.Settings().get_settings()

    def _set_labels( self ):
        xbmcgui.lock()
        try:
            self.getControl( 20 ).setLabel( __scriptname__ )
            self.getControl( 30 ).setLabel( "%s: %s" % ( _( 1006 ), __version__, ) )
            self.getControl( 250 ).setLabel( _( 250 ) )
            self.getControl( 251 ).setLabel( _( 251 ) )
            self.getControl( 252 ).setLabel( _( 252 ) )
            self.getControl( 253 ).setLabel( _( 253 ) )
            ## setEnabled( False ) if not used
            #self.getControl( 253 ).setVisible( False )
            #self.getControl( 253 ).setEnabled( False )
            for x in range( 1, len( self.settings ) ):
                self.getControl( 200 + x ).setLabel( _( 200 + x ) )
        except: pass
        xbmcgui.unlock()

    def _set_functions( self ):
        self.functions = {}
        self.functions[ 250 ] = self._save_settings
        self.functions[ 251 ] = self._close_dialog
        self.functions[ 252 ] = self._update_script
        self.functions[ 253 ] = self._show_credits
        for x in range( 1, len( self.settings ) ):
            self.functions[ 200 + x ] = eval( "self._change_setting%d" % x )

##### Special defs, script dependent, remember to call them from _setup_special #################
    
    def _setup_special( self ):
        """ calls any special defs """
        self._setup_startup_categories()
        self._setup_thumbnail_display()
        self._setup_playback_mode()
        self._setup_trailer_quality()
        self._setup_skins()
        
    def _setup_startup_categories( self ):
        self.startup_categories = {}
        self.startup_titles = []
        for count, genre in enumerate( self.genres ):
            self.startup_categories[ count ] = str( genre )
        self.startup_categories[ utilities.FAVORITES ] = _( 152 )
        self.startup_categories[ utilities.DOWNLOADED ] = _( 153 )
        for title in self.startup_categories.values():
            self.startup_titles += [ title ]
        self.startup_titles.sort()

    def _setup_thumbnail_display( self ):
        self.thumbnail = ( _( 2050 ), _( 2051 ), _( 2052 ), )
        
    def _setup_playback_mode( self ):
        self.mode = ( _( 2030 ), _( 2031 ), "%s (videos)" % _( 2032 ), "%s (files)" % _( 2032 ), )
    
    def _setup_trailer_quality( self ):
        self.quality = ( _( 2020 ), _( 2021 ), _( 2022 ), )

    def _setup_skins( self ):
        """ special def for setting up scraper choices """
        self.skins = os.listdir( os.path.join( os.getcwd().replace( ";", "" ), "resources", "skins" ) )
        try: self.current_skin = self.skins.index( self.settings[ "skin" ] )
        except: self.current_skin = 0

    def _set_restart_required( self ):
        """ copies self.settings and adds any settings that require a restart on change """
        self.settings_original = self.settings.copy()
        self.settings_restart = ( "skin", )

###### End of Special defs #####################################################

    def _get_setting_from_category( self, category ):
        for key, value in self.startup_categories.items():
            if ( value == self.startup_titles[ category ] ):
                return key
        return 0

    def _get_category_from_setting( self, setting ):
        for count, value in enumerate( self.startup_titles ):
            if ( value == self.startup_categories[ setting ] ):
                return count
        return 0

    def _set_controls_values( self ):
        """ sets the value labels """
        xbmcgui.lock()
        try:
            self.getControl( 221 ).setLabel( self.settings[ "skin" ] )
            self.getControl( 222 ).setLabel( self.quality[ self.settings[ "trailer_quality" ] ] )
            self.getControl( 223 ).setLabel( self.mode[ self.settings[ "mode" ] ] )
            self.getControl( 224 ).setLabel( self.settings[ "save_folder" ] )
            self.getControl( 224 ).setEnabled( self.settings[ "mode" ] >= 1 )
            self.getControl( 204 ).setEnabled( self.settings[ "mode" ] >= 1 )
            self.getControl( 225 ).setLabel( self.thumbnail[ self.settings[ "thumbnail_display" ] ] )
            self.getControl( 226 ).setLabel( self.startup_categories[ self.settings[ "startup_category_id" ] ] )
            self.getControl( 227 ).setLabel( self.startup_categories[ self.settings[ "shortcut1" ] ] )
            self.getControl( 228 ).setLabel( self.startup_categories[ self.settings[ "shortcut2" ] ] )
            self.getControl( 229 ).setLabel( self.startup_categories[ self.settings[ "shortcut3" ] ] )
            self.getControl( 230 ).setSelected( self.settings[ "refresh_newest" ] )
        except: pass
        xbmcgui.unlock()

    def _change_setting1( self ):
        """ changes settings #1 """
        self.chooser = chooser.GUI( skin=self.skin )
        self.chooser.show_chooser( choices=self.skins, selection=self.current_skin, list_control=1, title="%s %s" % ( _( 200 ), _( 201 ) ) )
        if ( self.chooser.selection is not None ):
            self.current_skin = self.chooser.selection
            self.settings[ "skin" ] = self.skins[ self.current_skin ]
        del self.chooser
        self._set_controls_values()

    def _change_setting2( self ):
        """ changes settings #2 """
        self.chooser = chooser.GUI( skin=self.skin )
        self.chooser.show_chooser( choices=self.quality, selection=self.settings[ "trailer_quality" ], list_control=2, title="%s %s" % ( _( 200 ), _( 202 ) ) )
        if ( self.chooser.selection is not None ):
            self.settings[ "trailer_quality" ] = self.chooser.selection
        del self.chooser
        self._set_controls_values()

    def _change_setting3( self ):
        """ changes settings #3 """
        self.chooser = chooser.GUI( skin=self.skin )
        self.chooser.show_chooser( choices=self.mode, selection=self.settings[ "mode" ], list_control=2, title="%s %s" % ( _( 200 ), _( 203 ) ) )
        if ( self.chooser.selection is not None ):
            self.settings[ "mode" ] = self.chooser.selection
        del self.chooser
        self._set_controls_values()

    def _change_setting4( self ):
        """ changes settings #4 """
        shares = [ "video", "files" ][ self.settings[ "mode" ] == 3 ]
        self.settings[ "save_folder" ] = utilities._get_browse_dialog( self.settings[ "save_folder" ], _( 204 ), 3, shares )
        self._set_controls_values()

    def _change_setting5( self ):
        """ changes settings #5 """
        self.chooser = chooser.GUI( skin=self.skin )
        self.chooser.show_chooser( choices=self.thumbnail, selection=self.settings[ "thumbnail_display" ], list_control=2, title="%s %s" % ( _( 200 ), _( 205 ) ) )
        if ( self.chooser.selection is not None ):
            self.settings[ "thumbnail_display" ] = self.chooser.selection
        del self.chooser
        self._set_controls_values()

    def _change_setting6( self ):
        """ changes settings #6 """
        selection = self._get_category_from_setting( self.settings[ "startup_category_id" ] )
        self.chooser = chooser.GUI( skin=self.skin )
        self.chooser.show_chooser( choices=self.startup_titles, selection=selection, list_control=2, title="%s %s" % ( _( 200 ), _( 206 ) ) )
        if ( self.chooser.selection is not None ):
            self.settings[ "startup_category_id" ] = self._get_setting_from_category( self.chooser.selection )
        del self.chooser
        self._set_controls_values()

    def _change_setting7( self ):
        """ changes settings #7 """
        selection = self._get_category_from_setting( self.settings[ "shortcut1" ] )
        self.chooser = chooser.GUI( skin=self.skin )
        self.chooser.show_chooser( choices=self.startup_titles, selection=selection, list_control=2, title="%s %s" % ( _( 200 ), _( 207 ) ) )
        if ( self.chooser.selection is not None ):
            self.settings[ "shortcut1" ] = self._get_setting_from_category( self.chooser.selection )
        del self.chooser
        self._set_controls_values()

    def _change_setting8( self ):
        """ changes settings #8 """
        selection = self._get_category_from_setting( self.settings[ "shortcut2" ] )
        self.chooser = chooser.GUI( skin=self.skin )
        self.chooser.show_chooser( choices=self.startup_titles, selection=selection, list_control=2, title="%s %s" % ( _( 200 ), _( 208 ) ) )
        if ( self.chooser.selection is not None ):
            self.settings[ "shortcut2" ] = self._get_setting_from_category( self.chooser.selection )
        del self.chooser
        self._set_controls_values()

    def _change_setting9( self ):
        """ changes settings #9 """
        selection = self._get_category_from_setting( self.settings[ "shortcut3" ] )
        self.chooser = chooser.GUI( skin=self.skin )
        self.chooser.show_chooser( choices=self.startup_titles, selection=selection, list_control=2, title="%s %s" % ( _( 200 ), _( 209 ) ) )
        if ( self.chooser.selection is not None ):
            self.settings[ "shortcut3" ] = self._get_setting_from_category( self.chooser.selection )
        del self.chooser
        self._set_controls_values()

    def _change_setting10( self ):
        """ changes settings #10 """
        self.settings[ "refresh_newest" ] = not self.settings[ "refresh_newest" ]
        self._set_controls_values()

##### End of unique defs ######################################################
    
    def _save_settings( self ):
        """ saves settings """
        ok = utilities.Settings().save_settings( self.settings )
        if ( not ok ):
            ok = xbmcgui.Dialog().ok( __scriptname__, _( 230 ) )
        else:
            self._check_for_restart()

    def _check_for_restart( self ):
        """ checks for any changes that require a restart to take effect """
        restart = False
        for setting in self.settings_restart:
            if ( self.settings_original[ setting ] != self.settings[ setting ] ):
                restart = True
                break
        self._close_dialog( True, restart )
    
    def _update_script( self ):
        """ checks for updates to the script """
        import update
        updt = update.Update()
        del updt

    def _show_credits( self ):
        """ shows a credit window """
        import credits
        c = credits.GUI( "script-%s-credits.xml" % ( __scriptname__.replace( " ", "_" ), ), utilities.BASE_RESOURCE_PATH, "Default", skin=self.skin )
        c.doModal()
        del c

    def _close_dialog( self, changed=False, restart=False ):
        """ closes this dialog window """
        self.changed = changed
        self.restart = restart
        self.close()

    def onClick( self, controlId ):
        #xbmc.sleep(5)
        self.functions[ controlId ]()

    def onFocus( self, controlId ):
        pass

    def onAction( self, action ):
        if ( action.getButtonCode() in utilities.CANCEL_DIALOG ):
            self._close_dialog()
