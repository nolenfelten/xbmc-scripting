import os
import xbmcgui

EXIT_SCRIPT = ( 247, 275, 61467, )
CANCEL_DIALOG = EXIT_SCRIPT + ( 216, 257, 61448, )

class GUI( xbmcgui.WindowXML ):
    def __init__( self, *args, **kwargs ):
        xbmcgui.lock()

    def onInit( self ):
        self.getControl( 9001 ).setVisible( False )
        xbmcgui.unlock()

    def _close_dialog( self ):
        #self.removeControl( self.getControl( 9000 ) )
        #self.removeControl( self.getControl( 9001 ) )
        self.close()

    def onClick( self, controlId ):
        self.getControl( 9000 ).setVisible( controlId in ( 102, 103, ) )
        self.getControl( 9001 ).setVisible( controlId in ( 100, 101, ) )
        self.setFocus( self.getControl( 100 + ( 2 * ( controlId in ( 100, 101, ) ) ) ) )

    def onFocus( self, controlId ):
        pass

    def onAction( self, action ):
        if ( action.getButtonCode() in CANCEL_DIALOG ):
            self._close_dialog()

if __name__ == "__main__":
    ui = GUI( "GroupTest.xml", os.getcwd().replace( ";", "" ), "Default", False )
    ui.doModal()
    del ui
