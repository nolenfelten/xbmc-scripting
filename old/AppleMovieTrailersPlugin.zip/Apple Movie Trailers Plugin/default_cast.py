# main import's
import sys
import os
import xbmc
import xbmcgui
import xbmcplugin

from pysqlite2 import dbapi2 as sqlite

import traceback

# Script constants
__plugin__ = "Apple Movie Trailers"
__author__ = "Nuka1195"
__url__ = "http://code.google.com/p/xbmc-scripting/"
__svn_url__ = "http://xbmc-scripting.googlecode.com/svn/trunk/Apple%20Movie%20Trailers"
__credits__ = "XBMC TEAM, freenode/#xbmc-scripting"
__version__ = "1.0"

BASE_DATABASE_PATH = xbmc.translatePath( os.path.join( "T:\\script_data", __plugin__ ) )
BASE_SETTINGS_PATH = xbmc.translatePath( os.path.join( "P:\\script_data", __plugin__ ) )


class Main:
    """ 
        Main plugin class
        - url = sys.argv[ 0 ]
        - handle = sys.argv[ 1 ]
        - params =  sys.argv[ 2 ]
    """
    def __init__( self, *args, **kwargs ):
        self.query = Query()
        if ( not sys.argv[ 2 ] ):
            self.get_genres()
        else:
            self.get_trailers()

    def get_genres( self ):
        """ Grabs the genre list """
        try:
            ok = True
            genres = self._fetch_records( self.query[ "genres" ] )
            for genre in genres:
                url = "%s?genre=%d&title=%s&mode=%d&quality=%d" % ( sys.argv[ 0 ], genre[ 0 ], genre[ 1 ], 0, 2, )
                listitem=xbmcgui.ListItem( genre[ 1 ], "(%d)" % genre[ 2 ] )
                listitem.setInfo( type="Video", infoLabels={ "Date": "%s-%s-%s" % ( genre[ 4 ][ 8 : ], genre[ 4 ][ 5 : 7 ], genre[ 4 ][ : 4 ], ) } )
                ok = xbmcplugin.addDirectoryItem( handle=int(sys.argv[ 1 ]), url=url, listitem=listitem, isFolder=True, totalItems=len(genres) )
                if ( not ok ): raise
        except:
            ok = False
            #traceback.print_exc()
        xbmcplugin.endOfDirectory( handle=int( sys.argv[ 1 ] ), succeeded=ok )

    def _get_args( self ):
        args = sys.argv[ 2 ].split( "&" )
        retargs = []
        for arg in args:
            retargs += [ arg.split( "=" )[ 1 ] ]
        return int( retargs[ 0 ] ), retargs[ 1 ], int( retargs[ 2 ] ), int( retargs[ 3 ] )

    def get_trailers( self ):
        try:
            ok = True
            genre, title, mode, quality = self._get_args()
            trailers = self._fetch_records( self.query[ "movies" ], ( genre, ) )
            
            ftrailers = ()
            movie_id = trailers[ 0 ][ 0 ]
            tmp_trailer = trailers[ 0 ][ : 14 ]
            for trailer in trailers:
                if ( trailer[ 0 ] != movie_id ):
                    ftrailers += ( tmp_trailer, )
                    movie_id = trailer[ 0 ]
                    tmp_trailer = trailer
                else:
                    tmp_trailer += ( trailer[ 14 ], )
            ftrailers += ( tmp_trailer, )
            for trailer in ftrailers:
                if ( trailer[ 12 ] ):
                    url = trailer[ 12 ]
                else:
                    url = ""
                    trailer_urls = eval( trailer[ 3 ] )
                    choice = ( quality, len( trailer_urls ) - 1, )[ quality >= len( trailer_urls ) ]
                    if ( quality <= 2 ):
                        while ( trailer_urls[ choice ].endswith( "p.mov" ) and choice != -1 ): choice -= 1
                    if ( choice >= 0 ):
                        url = trailer_urls[ choice ]
                if ( url ):
                    thumbnail = ""
                    if ( trailer[ 4 ] and trailer[ 4 ] is not None ):
                        thumbnail = os.path.join( BASE_DATABASE_PATH, ".cache", trailer[ 4 ][ 0 ], trailer[ 4 ] )
                    rating = ( "", "[%s]" % trailer[ 6 ], )[ trailer[ 6 ] != "" ]
                    plot = ( "No synopsis provided by the studio.", trailer[ 5 ], )[ trailer[ 5 ] != "" ]
                    listitem = xbmcgui.ListItem( trailer[ 1 ], rating, thumbnailImage=thumbnail )
                    listitem.setInfo( type="Video", infoLabels={ "Genre": title, "MPAARating": rating, "Plot": plot, "Title": trailer[ 1 ], "Cast": list( trailer[ 14 : ] ) } )
                    ok = xbmcplugin.addDirectoryItem( handle=int( sys.argv[ 1 ] ), url=url, listitem=listitem, totalItems=len(ftrailers) )
                    if ( not ok ): raise
        except:
            ok = False
            traceback.print_exc()
        if ( ok ):
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )
        xbmcplugin.endOfDirectory( handle=int( sys.argv[ 1 ] ), succeeded=ok )

    def _fetch_records( self, query, params=None ):
        records = Records()
        result = records.fetch( query, params )
        records.close()
        return result


class Records:
    "add, delete, update and fetch records"
    def __init__( self, *args, **kwargs ):
        self.connect()

    def connect( self ):
        self.db = sqlite.connect( os.path.join( BASE_DATABASE_PATH, "AMT.db" ) )
        self.cursor = self.db.cursor()
    
    def close( self ):
        self.db.close()
    
    def fetch( self, sql, params=None ):
        try:
            if ( params is not None ): self.cursor.execute( sql , params )
            else: self.cursor.execute( sql )
            retval = self.cursor.fetchall()
        except:
            retval = None
        return retval


class Query( dict ):
	"all sql statments. add as needed"
	def __init__( self ):
		self[ "movies" ] = """
									SELECT movies.*, actors.actor 
									FROM movies, genre_link_movie, actor_link_movie, actors 
									WHERE genre_link_movie.idMovie=movies.idMovie 
									AND genre_link_movie.idGenre=? 
									AND movies.trailer_urls IS NOT NULL 
									AND movies.trailer_urls!='[]' 
									AND actor_link_movie.idMovie=movies.idMovie 
									AND actor_link_movie.idActor=actors.idActor 
									ORDER BY movies.title;
								"""

		self[ "genres" ] = """	
									SELECT genres.idGenre, genres.genre, count(genre_link_movie.idGenre), count(movies.favorite), genres.updated 
									FROM genre_link_movie, genres, movies 
									WHERE genre_link_movie.idGenre=genres.idGenre 
									AND genre_link_movie.idMovie=movies.idMovie 
									GROUP BY genres.genre;
								"""

Main()
