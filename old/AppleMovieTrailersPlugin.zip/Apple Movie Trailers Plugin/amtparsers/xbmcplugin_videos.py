"""
    Videos module: fetches a list of playable streams for a specific category
"""

# main imports
import sys
import os
import xbmc
import xbmcgui
import xbmcplugin

from pysqlite2 import dbapi2 as sqlite
import traceback

# base paths
BASE_DATABASE_PATH = sys.modules[ "__main__" ].BASE_DATABASE_PATH
BASE_DATA_PATH = xbmc.translatePath( os.path.join( "T:\\", "script_data", sys.modules[ "__main__" ].__plugin__ ) )


class _Info:
    """
        Create an _Info object
    """
    def __init__( self, *args, **kwargs ):
        self.__dict__.update( kwargs )


class Main:
    def __init__( self ):
        self._parse_argv()
        self.get_videos()

    def _parse_argv( self ):
        # call _Info() with our formatted argv to create the constants
        exec "self.args = _Info(%s)" % ( sys.argv[ 2 ].replace( "?", "" ).replace( "=", "='" ).replace( "&", "', " ) + "'", )

    def get_videos( self ):
        try:
            # fetch trailers from database
            trailers = self._fetch_records()
            # concatenate actors
            trailers = self._parse_actors( trailers )
            # fill media list
            ok = self._fill_media_list( trailers )
        except:
            # oops print error message
            print sys.exc_info()[ 1 ]
            ok = False
        # send notification we're finished, successfully or unsuccessfully
        xbmcplugin.endOfDirectory( handle=int( sys.argv[ 1 ] ), succeeded=ok )

    def _parse_actors( self, trailers ):
        ftrailers = []
        idMovie = -1
        # enumerate through the list of trailers, eliminating duplicates and adding the actors to the cast list
        for trailer in trailers:
            # if it's a new trailer convert the tuple to a list and add the actor as a cast list
            if ( trailer[ 0 ] != idMovie ):
                idMovie = trailer[ 0 ]
                ftrailers += [ list( trailer[ : 16 ] ) ]
                ftrailers[ -1 ] += [ [ trailer[ 16 ] ] ]
            else:
                # add the next actor to the cast list
                ftrailers[ -1 ][ 16 ] += [ trailer[ 16 ] ]
        return ftrailers

    def _fill_media_list( self, trailers ):
        try:
            ok = True
            # enumerate through the list of trailers and add the item to the media list
            for trailer in trailers:
                # if trailer was saved use this as the url
                if ( trailer[ 13 ] ):
                    url = trailer[ 13 ]
                else:
                    # select the correct trailer quality.
                    url = self._get_trailer_url( eval( trailer[ 3 ] ) )
                if ( url ):
                    # check for a valid thumbnail
                    thumbnail = ""
                    if ( trailer[ 4 ] and trailer[ 4 ] is not None ):
                        thumbnail = os.path.join( BASE_DATA_PATH, ".cache", trailer[ 4 ][ 0 ], trailer[ 4 ] )
                    # if a rating exists format it
                    rating = ( "", "[%s]" % trailer[ 7 ], )[ trailer[ 7 ] != "" ]
                    # if a plot does not exist, use a default message
                    plot = ( "No synopsis provided by the studio.", trailer[ 5 ], )[ trailer[ 5 ] != "" ]
                    # only need to add label and thumbnail, setInfo() and addSortMethod() takes care of label2
                    listitem = xbmcgui.ListItem( trailer[ 1 ], rating, thumbnailImage=thumbnail )
                    # add the different infolabels we want to sort by
                    listitem.setInfo( type="Video", infoLabels={ "Cast": trailer[ 16 ], "Runtime": trailer[ 6 ], "Studio": trailer[ 15 ], "Genre": self.args.genre, "MPAARating": rating, "Plot": plot, "Title": trailer[ 1 ], "year": trailer[ 9 ] } )
                    # add the item to the media list
                    ok = xbmcplugin.addDirectoryItem( handle=int( sys.argv[ 1 ] ), url=url, listitem=listitem, totalItems=len(trailers) )
                    # if user cancels, call raise to exit loop
                    if ( not ok ): raise
        except:
            # user cancelled dialog or an error occurred
            print sys.exc_info()[ 1 ]
            ok = False
        # if successful and user did not cancel, add all the required sort methods
        if ( ok ):
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_YEAR )
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_STUDIO )
        return ok

    def _get_trailer_url( self, trailer_urls ):
        url = ""
        # get intial choice
        choice = ( int( self.args.quality ), len( trailer_urls ) - 1, )[ int( self.args.quality ) >= len( trailer_urls ) ]
        # if quality is non progressive
        if ( int( self.args.quality ) <= 2 ):
            # select the correct non progressive trailer
            while ( trailer_urls[ choice ].endswith( "p.mov" ) and choice != -1 ): choice -= 1
        # quality is progressive
        else:
            # select the proper progressive quality
            quality = ( "480p", "720p", "1080p", )[ int( self.args.quality ) - 3 ]
            # select the correct progressive trailer
            while ( quality not in trailer_urls[ choice ] and trailer_urls[ choice ].endswith( "p.mov" ) and choice != -1 ): choice -= 1
        # if there was a valid trailer set it
        if ( choice >= 0 ):
            url = trailer_urls[ choice ]
        return url

    def _fetch_records( self ):
        records = Records()
        result = records.fetch( Query()[ "movies" ], ( int( self.args.genre_id ), ) )
        records.close()
        return result


class Records:
    def __init__( self, *args, **kwargs ):
        self.connect()

    def connect( self ):
        self.db = sqlite.connect( os.path.join( BASE_DATABASE_PATH, "AMT.db" ) )
        self.cursor = self.db.cursor()
    
    def close( self ):
        self.db.close()
    
    def fetch( self, sql, params=None ):
        try:
            if ( params is not None ): self.cursor.execute( sql, params )
            else: self.cursor.execute( sql )
            retval = self.cursor.fetchall()
        except:
            retval = None
        return retval


class Query( dict ):
    def __init__( self ):
        self[ "movies" ] = """
                                    SELECT movies.*, studios.studio, actors.actor 
                                    FROM movies, genre_link_movie, studios, studio_link_movie, actors, actor_link_movie 
                                    WHERE genre_link_movie.idMovie=movies.idMovie 
                                    AND genre_link_movie.idGenre=? 
                                    AND movies.trailer_urls IS NOT NULL 
                                    AND movies.trailer_urls!='[]' 
                                    AND studio_link_movie.idMovie=movies.idMovie 
                                    AND studio_link_movie.idStudio=studios.idStudio 
                                    AND actor_link_movie.idMovie=movies.idMovie 
                                    AND actor_link_movie.idActor=actors.idActor 
                                    ORDER BY movies.title;
                                """
