"""
Apple Movie Trailers Plugin by Nuka1195

 - url = sys.argv[ 0 ]
 - handle = sys.argv[ 1 ]
 - params =  sys.argv[ 2 ]

"""

import sys
import os
import xbmc
import xbmcgui
from pysqlite2 import dbapi2 as sqlite
import re
import traceback

BASE_DATABASE_PATH = "T:\\script_data\\Apple Movie Trailers"
BASE_SETTINGS_PATH = "P:\\script_data\\Apple Movie Trailers"

class Main:
    """ Main database class """
    def __init__( self, *args, **kwargs ):
        self.query = Query()
        if ( sys.argv[ 2 ] == "" ):
            self.get_genres()
        else:
            self.get_trailers()
            
    def get_genres( self ):
        try:
            records = Records()
            genres = records.fetch( self.query[ "genre_category_list" ], (), all=True )
            records.close()
            for genre in genres:
                url = "%s?genre=%d&mode=%d&quality=%d" % ( sys.argv[ 0 ], genre[ 0 ], 0, 2, )
                #xbmc.setDirectoryEntry( handle=int( sys.argv[ 1 ] ), name=genre[ 1 ], url=url, isDirectory=True )
                xbmc.setDirectoryEntry( handle=int( sys.argv[ 1 ] ), url=url, listitem=xbmcgui.ListItem( genre[ 1 ], "(%d)" % genre[ 2 ] ), isFolder=True )
        except: traceback.print_exc()
        xbmc.endOfDirectory( handle=int( sys.argv[ 1 ] ) )

    def get_trailers( self ):
        args = sys.argv[ 2 ].split( "&" )
        genre = int( args[ 0 ][ 7 : ] )
        mode = int( args[ 1 ][ 5 : ] )
        quality = int( args[ 2 ][ 8 : ] )
        records = Records()
        trailers = records.fetch( self.query[ "movies_by_genre_id" ], ( genre, ), all=True )
        records.close()
        try:
            for trailer in trailers:
                if ( trailer[ 12 ] ):
                    url = trailer[ 12 ]
                else:
                    url = ""
                    if ( trailer[ 3 ] is not None ):
                        trailer_urls = eval( trailer[ 3 ] )
                        if ( len( trailer_urls ) ):
                            choice = ( quality, len( trailer_urls ) - 1, )[ quality >= len( trailer_urls ) ]
                            if ( quality <= 2 ):
                                while ( trailer_urls[ choice ].endswith( "p.mov" ) and choice != -1 ): choice -= 1
                            if ( choice >= 0 ):
                                url = trailer_urls[ choice ]
                if ( url ):
                    iconpath = ""
                    if ( trailer[ 4 ] and trailer[ 4 ] is not None ):
                        iconpath = os.path.join( BASE_DATABASE_PATH, ".cache", trailer[ 4 ][ 0 ], trailer[ 4 ] )
                    rating = ( "", "[%s]" % trailer[ 6 ], )[ trailer[ 6 ] != "" ]
                    #xbmc.setDirectoryEntry( handle=int( sys.argv[ 1 ] ), name=trailer[ 1 ], iconpath=iconpath, url=url, isDirectory=False )
                    xbmc.setDirectoryEntry( handle=int( sys.argv[ 1 ] ), url=url, listitem=xbmcgui.ListItem( trailer[ 1 ], rating, iconpath, iconpath ), isFolder=False )
            xbmc.endOfDirectory( handle=int( sys.argv[ 1 ] ) )
        except: traceback.print_exc()


class Records:
    "add, delete, update and fetch records"
    def __init__( self, *args, **kwargs ):
        self.connect()

    def connect( self ):
        self.db = sqlite.connect( os.path.join( BASE_DATABASE_PATH, "AMT.db" ) )#, detect_types=sqlite.PARSE_DECLTYPES|sqlite.PARSE_COLNAMES)
        self.db.create_function( "regexp", 2, self.regexp )
        self.cursor = self.db.cursor()
    
    def regexp( self, pattern, item ):
        return re.search( pattern, item, re.IGNORECASE ) is not None

    def commit( self ):
        try:
            self.db.commit()
            return True
        except: return False
    
    def close( self ):
        self.db.close()
    
    def fetch( self, sql, params=None, all=False ):
        try:
            if ( params is not None ): self.cursor.execute( sql , params )
            else: self.cursor.execute( sql )
            if ( all ): retval = self.cursor.fetchall()
            else: retval = self.cursor.fetchone()
        except:
            retval = None
        return retval


class Query( dict ):
    "all sql statments. add as needed"
    def __init__( self ):
        #good sql statements
        self[ "movie_by_movie_id" ]		= "SELECT movies.* FROM movies WHERE movies.idMovie=?;"
        self[ "studio_by_movie_id" ]		= "SELECT studios.studio FROM studio_link_movie, studios WHERE studio_link_movie.idStudio = studios.idStudio AND studio_link_movie.idMovie=?;"
        self[ "actors_by_movie_id" ]		= "SELECT actors.actor FROM actor_link_movie, actors WHERE actor_link_movie.idActor = actors.idActor AND actor_link_movie.idMovie=? ORDER BY actors.actor;"

        self[ "movies_by_genre_id" ]		= "SELECT movies.* FROM movies, genre_link_movie WHERE genre_link_movie.idMovie=movies.idMovie AND genre_link_movie.idGenre=? ORDER BY movies.title;"
        self[ "movies_by_studio_id" ]		= "SELECT movies.* FROM movies, studio_link_movie WHERE studio_link_movie.idMovie=movies.idMovie AND studio_link_movie.idStudio=? ORDER BY movies.title;"
        self[ "movies_by_actor_id" ]		= "SELECT movies.* FROM movies, actor_link_movie WHERE actor_link_movie.idMovie=movies.idMovie AND actor_link_movie.idActor=? ORDER BY movies.title;"

        self[ "movies_by_genre_name" ]	= "SELECT movies.* FROM movies, genres, genre_link_movie WHERE genre_link_movie.idGenre=genres.idGenre AND genre_link_movie.idMovie=movies.idMovie AND genres.genre=? ORDER BY movies.title;"
        self[ "movies_by_studio_name" ]= "SELECT movies.* FROM movies, studios, studio_link_movie WHERE studio_link_movie.idStudio=studios.idStudio AND studio_link_movie.idMovie=movies.idMovie AND upper(studios.studio)=? ORDER BY movies.title;"
        self[ "movies_by_actor_name" ]	= "SELECT movies.* FROM movies, actors, actor_link_movie WHERE actor_link_movie.idActor=actors.idActor AND actor_link_movie.idMovie=movies.idMovie AND actors.actor LIKE ? ORDER BY movies.title;"

        self[ "incomplete_movies" ]		= "SELECT * FROM movies WHERE trailer_urls IS NULL ORDER BY title;"
        self[ "version" ]						= "SELECT * FROM version;"

        self[ "genre_category_list" ]		= "SELECT genres.idGenre, genres.genre, count(genre_link_movie.idGenre), count(movies.favorite) FROM genre_link_movie, genres, movies WHERE genre_link_movie.idGenre=genres.idGenre AND genre_link_movie.idMovie=movies.idMovie GROUP BY genres.genre;"
        self[ "studio_category_list" ]		= "SELECT studios.idStudio, studios.studio, count(studio_link_movie.idStudio), count(studio_link_movie.idStudio) FROM studio_link_movie, studios WHERE studio_link_movie.idStudio=studios.idStudio GROUP BY upper(studios.studio);"
        self[ "actor_category_list" ]		= "SELECT actors.idActor, actors.actor, count(actor_link_movie.idActor), count(actor_link_movie.idActor) FROM actor_link_movie, actors WHERE actor_link_movie.idActor=actors.idActor GROUP BY upper(actors.actor);"
        self[ "rating_category_list" ]		= "SELECT movies.rating, count(movies.rating) FROM movies WHERE movies.rating IS NOT NULL AND movies.rating!='' GROUP BY rating;"

        self[ "genre_table_list" ]			= "SELECT idGenre, genre, updated FROM genres ORDER BY genre;"
        self[ "genre_urls_by_genre_id" ]	= "SELECT urls FROM genres WHERE idGenre=?;"
        self[ "idMovie_by_genre_id" ]		= "SELECT idMovie FROM genre_link_movie WHERE idGenre=?;"
        self[ "idMovie_in_genre" ]			= "SELECT * FROM genre_link_movie WHERE idGenre=? AND idMovie=?;"

        self[ "movie_exists" ]				= "SELECT idMovie FROM movies WHERE upper(title)=?;"
        self[ "actor_exists" ]				= "SELECT idActor FROM actors WHERE upper(actor)=?;"
        self[ "studio_exists" ]				= "SELECT idStudio FROM studios WHERE upper(studio)=?;"

        self[ "favorites" ]						= "SELECT * FROM movies WHERE favorite=? ORDER BY title;"
        self[ "downloaded" ]					= "SELECT * FROM movies WHERE saved_location!=? ORDER BY title;"
        self[ "watched" ]						= "SELECT * FROM movies WHERE times_watched>? ORDER BY title;"

        self[ "hd_trailers" ]					= "SELECT * FROM movies WHERE trailer_urls LIKE ? ORDER BY title;"
        self[ "no_trailer_urls" ]				= "SELECT * FROM movies WHERE (trailer_urls=? OR trailer_urls IS NULL) AND poster IS NOT NULL ORDER BY title;"
        self[ "simple_search" ]				= """SELECT DISTINCT movies.*
                                                        FROM movies
                                                        JOIN actor_link_movie
                                                        ON movies.idMovie=actor_link_movie.idMovie
                                                        JOIN actors
                                                        ON actor_link_movie.idActor=actors.idActor
                                                        JOIN studio_link_movie
                                                        ON movies.idMovie=studio_link_movie.idMovie
                                                        JOIN studios
                                                        ON studio_link_movie.idStudio=studios.idStudio
                                                        JOIN genre_link_movie
                                                        ON movies.idMovie=genre_link_movie.idMovie
                                                        JOIN genres
                                                        ON genre_link_movie.idGenre=genres.idGenre
                                                        WHERE %s ORDER BY title;""" 

Main()
