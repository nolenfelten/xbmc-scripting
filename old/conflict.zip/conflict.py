import xbmcgui
import xbmc


class GUI( xbmcgui.WindowDialog ):
    def __init__( self ):
        self.image = xbmcgui.ControlImage( 90,90, 320, 200, "keyboard-numeric-bg.png" )
        self.addControl( self.image )
        self.button1 = xbmcgui.ControlButton( 120,100, 90, 30, "Button1" )
        self.addControl( self.button1 )
        self.label1 = xbmcgui.ControlLabel( 250,100, 100, 30, "label here" )
        self.addControl( self.label1 )
        self.button2 = xbmcgui.ControlButton( 120,150, 90, 30, "Button2" )
        self.addControl( self.button2 )
        self.button1.controlDown( self.button2 )
        self.button2.controlDown( self.button1 )
        self.setFocus( self.button1 )
    
    def load_child( self ):
        cui = GUI_Child()
        cui.doModal()
        del cui

    def onControl( self, control ):
        if ( control is self.button1 ):
            self.label1.setLabel( "button1" )
        elif ( control is self.button2 ):
            self.label1.setLabel( "label here" )
            self.load_child()
            
    def onAction( self, action ):
        if ( action == 10 ): self.close()
            

class GUI_Child( xbmcgui.WindowDialog ):
    def __init__( self ):
        self.image = xbmcgui.ControlImage( 490,90, 320, 200, "keyboard-numeric-bg.png" )
        self.addControl( self.image )
        self.list1 = xbmcgui.ControlList( 520,100, 200, 200, "font13", "ffffffff", "list-nofocus.png", "list-focus.png" )
        self.addControl( self.list1 )
        for i in range(10):
            self.list1.addItem("This is a conflicting list %d" % i )
        self.setFocus( self.list1 )

    def onControl( self, control ):
        pass
        
    def onAction( self, action ):
        if ( action == 10 ): self.close()
            


if __name__ == '__main__':
    ui = GUI()
    ui.doModal()
    del ui
