import xbmc
 
trailer = "http://movies.apple.com/movies/wb/16_blocks/16_blocks_h480p.mov"
trailer = "http://movies.apple.com/movies/fox_atomic/28_weeks_later/28_weeks_later-tlra_h480p.mov"
    
xbmc.Player( xbmc.PLAYER_CORE_DVDPLAYER ).play( trailer )