"""
    Plugin Maker: This plugin will create a directory listing of VIDEO_PATH and add videos.
"""
import os
import sys
import xbmc
import xbmcgui
import xbmcplugin

import datetime


class Main:
    # base paths
    BASE_CACHE_PATH = os.path.join( "P:\\", "Thumbnails", "Video" )
    # TODO: Make this replaceble
    VIDEO_PATH = ###VIDEO_PATH###

    # add all video extensions wanted in lowercase
    VIDEO_EXT = ".wmv|.avi|.mov|.mpg"

    def __init__( self ):
        self.get_videos()

    def get_videos( self ):
        try:
            videos = []
            # get the video list by walking VIDEO_PATH recursively
            os.path.walk( self.VIDEO_PATH, self.add_video, videos )
            # fill media list
            ok = self._fill_media_list( videos )
        except:
            # oops print error message
            print sys.exc_info()[ 1 ]
            ok = False
        # send notification we're finished, successfully or unsuccessfully
        xbmcplugin.endOfDirectory( handle=int( sys.argv[ 1 ] ), succeeded=ok )

    def add_video( self, videos, path, files ):    
        for file in files:
            ext = os.path.splitext( file )[ 1 ].lower()
            if ( ext and ext in self.VIDEO_EXT ):
                videos += [ os.path.join( path, file ) ]

    def _fill_media_list( self, videos ):
        try:
            ok = True
            # enumerate through the list of videos and add the item to the media list
            for video in videos:
                # call _get_thumbnail() for the path to the cached thumbnail
                thumbnail = self._get_thumbnail( video )
                title = os.path.splitext( os.path.basename( video ) )[ 0 ]
                seconds = os.path.getmtime( video )
                date = datetime.datetime.fromtimestamp( seconds ).strftime( "%d-%m-%Y" )
                size = os.path.getsize( video )
                # only need to add label and thumbnail, setInfo() and addSortMethod() takes care of label2
                listitem=xbmcgui.ListItem( label=title, thumbnailImage=thumbnail )
                # add the different infolabels we want to sort by
                listitem.setInfo( type="Video", infoLabels={ "Title": title, "Date": date, "Size": size } )
                # add the item to the media list
                ok = xbmcplugin.addDirectoryItem( handle=int( sys.argv[ 1 ] ), url=video, listitem=listitem, totalItems=len( videos ) )
                # if user cancels, call raise to exit loop
                if ( not ok ): raise
        except:
            # user cancelled dialog or an error occurred
            print sys.exc_info()[ 1 ]
            ok = False
        # if successful and user did not cancel, add all the required sort methods
        if ( ok ):
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
            xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_SIZE )
        return ok

    def _get_thumbnail( self, video ):
        # make the proper cache filename and path so duplicate caching is unnecessary
        filename = xbmc.getCacheThumbName( video )
        filepath = xbmc.translatePath( os.path.join( self.BASE_CACHE_PATH, filename[ 0 ], filename ) )
        try:
            # if the cached thumbnail does not exist create the thumbnail
            if ( not os.path.isfile( filepath ) ):
                # create filepath to a local tbn file
                filepath = os.path.splitext( video )[ 0 ] + ".tbn"
            return filepath
        except:
            # return empty string if creation failed
            print sys.exc_info()[ 1 ]
            return ""


if ( __name__ == "__main__" ):
    Main()
