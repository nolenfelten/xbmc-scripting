"""
This script will create a playlist by recursively searching MUSIC_PATH and adding songs.
"""
import os
import shutil
import xbmcgui


class Main:
    def __init__( self ):
        path = self.get_browse_dialog( heading="Browse for video directory" )
        if ( path ):
            self.create_plugin( path )

    def get_browse_dialog( self, default="", heading="", dlg_type=0, shares="files", mask="", use_thumbs=False, treat_as_folder=False ):
        """ shows a browse dialog and returns a value
            - 0 : ShowAndGetDirectory
            - 1 : ShowAndGetFile
            - 2 : ShowAndGetImage
            - 3 : ShowAndGetWriteableDirectory
        """
        dialog = xbmcgui.Dialog()
        value = dialog.browse( dlg_type, heading, shares, mask, use_thumbs, treat_as_folder, default )
        return value

    def create_plugin( self, path ):
        plugin = os.path.join( os.getcwd().replace( ";", "" ), "plugin.py" )
        plugin_path = os.path.join( "Q:\\", "plugins", "video", os.path.basename( path[ : -1 ] ) + " plugin" )
        if ( not os.path.isdir( plugin_path ) ):
            os.makedirs( plugin_path )
        try:
            # TODO: copy a generic thumb also or browse for thumb
            shutil.copy( plugin, os.path.join( plugin_path, "default.py" ) )
            self.edit_videopath( os.path.join( plugin_path, "default.py" ), path )
        except:
            ok = xbmcgui.Dialog().ok( "Plugin Maker", "Copying plugin to new plugin folder failed!" )

    def edit_videopath( self, filepath, sourcepath ):
        try:
            # read .py file
            file_object = open( filepath, "r" )
            data = file_object.read()
            file_object.close()
            # write new .py file
            file_object = open( filepath, "w" )
            file_object.write( data.replace( "###VIDEO_PATH###", '"%s"' % sourcepath.replace( "\\", "\\\\" ) ) )
            file_object.close()
        except:
            ok = xbmcgui.Dialog().ok( "Plugin Maker", "Copying plugin to new plugin folder failed!" )

if ( __name__ == "__main__" ):
    Main()
