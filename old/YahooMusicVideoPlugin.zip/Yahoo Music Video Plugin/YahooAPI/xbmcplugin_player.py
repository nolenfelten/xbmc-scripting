"""
    Player module: plays the selected video
"""

# create the progress dialog (we do it here so there is minimal delay with nothing displayed)
import xbmcgui
pDialog = xbmcgui.DialogProgress()
pDialog.create( "Yahoo Music Videos Plugin", "Getting session ID..." )

# main imports
import sys
import xbmc
import urllib
import traceback

from YahooAPI.YahooClient import YahooClient


class _Info:
    def __init__( self, *args, **kwargs ):
        self.__dict__.update( kwargs )


class Main:
    def __init__( self ):
        self._parse_argv()
        #self.download_video()
        self.play_video()

    def _parse_argv( self ):
        # call _Info() with our formatted argv to create the self.args object
        exec "self.args = _Info(%s)" % ( sys.argv[ 2 ][ 1 : ].replace( "&", ", " ).replace( "\\u0027", "'" ).replace( "\\u0022", '"' ).replace( "\\u0026", "&" ), )
        self.args.url = self.args.url.replace( "-*-*-", "&" )

    def download_video( self ):
        try:
            client = YahooClient()
            if ( "yahoo" in self.args.url ):
                url = client.construct_yahoo_video_url( self.args.url )
            elif ( "youtube" in self.args.url ):
                url = client.construct_youtube_video_url( self.args.url )
            else:
                url = self.args.url
            # TODO: set a user path and see if file exists
            urllib.urlretrieve( url, "Z:\\yahoovideo.mov", self._report_hook )
            pDialog.close()
            #self.play_video()
        except:
            pDialog.close()

    def _report_hook( self, count, blocksize, totalsize ):
        percent = int( float( count * blocksize * 100) / totalsize )
        pDialog.update( percent )
        if ( pDialog.iscanceled() ): raise

    def play_video( self ):
        try:
            client = YahooClient()
            if ( "yahoo" in self.args.url ):
                url = client.construct_yahoo_video_url( self.args.url )
            elif ( "youtube" in self.args.url ):
                url = client.construct_youtube_video_url( self.args.url )
            else:
                url = self.args.url
            pDialog.close()
            if ( not pDialog.iscanceled() ):
                listitem = xbmcgui.ListItem( self.args.title, thumbnailImage=self.args.thumbnail )
                listitem.setInfo( "video", { "Title": self.args.title, "Studio": self.args.studio } )
                xbmc.Player( xbmc.PLAYER_CORE_MPLAYER ).play( url, listitem )
        except:
            traceback.print_exc()
        # TODO: maybe call endOfDirectory()
