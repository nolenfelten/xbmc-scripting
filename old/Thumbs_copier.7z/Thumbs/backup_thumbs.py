import os
import binascii
import shutil

base_path = os.getcwd().replace( ";", "" )
base_cache_path = "q:\\UserData\\Thumbnails\\Video"
thumb_folder = os.path.join( base_path, "thumbs" )

def calculate_crc( path ):
    return abs( binascii.crc32( path ) )

def copy_thumbs( paths ):
    for path in paths:
        hex_filename = "%08x.tbn" % calculate_crc( path.replace( "\n", "" ) )
        print path.replace( "\n", "" )
        print os.path.join( base_cache_path, hex_filename )
        print "-----------------------------"

def read_path_file():
    file_object = open( os.path.join( base_path, "path_file.txt" ), "r" )
    paths = file_object.readlines()
    file_object.close()
    return paths


if ( __name__ == "__main__" ):
    paths = read_path_file()
    copy_thumbs( paths )
    