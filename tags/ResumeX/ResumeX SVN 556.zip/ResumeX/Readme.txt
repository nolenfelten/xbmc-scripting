      ##########################
      #                        #                      
      #   ResumeX (V.0.4)      #         
      #     By Stanley87       #         
      #                        #
#######                        #######             
#                                    #
#                                    #
#   An Auto Resume script for XBMC   #
#                                    #
######################################

Fixed V.0.4:
**Fixed - Problem with Video playlist wrongly being loaded as music playlist on
startup.
**Updated - Script won't replace window if window ID = 10000 (main window)


Fixed V.0.3:
**Fixed playlist problems
**Clean up script a little


Fixed V.0.2:
**Fixed Video resume problems :-D


Features:

**Resume on xbmc startup the last song/video XBMC was playing on exit
**Resume on xbmc startup the last window XBMC was in on exit (optional)
**Resume on xbmc startup the last playlist XBMC was playing on exit
**Resume on xbmc startup the song/video position XBMC was playing on exit
**Disable/Enable ResumeX via ResumeX gui script
**Disable/Enable Window Resume via ResumeX gui script


-------------------------------------------------------------------------------
Install:

Run build.bat

Copy the ResumeX folder from in the build foler to your xbmc/scripts folder.

Run ResumeX from scripts menu in Xbmc to set up autostart script.

Note:
If you already have an autoexec.py file in your xbmc/scripts folder
then please edit this to add in the new line for my script,
otherwise this script will replace this file.



------------------------------------------------------------------------------------
Support SICKCYCLE!!, visit www.myspace.com/sickcyclenz, Drum n' Bass MASSIVE!!
------------------------------------------------------------------------------------

Bug Reports/Feature Suggestions/Fan Mail :-p /Comments???
PM ME : www.xboxmediacenter.com/forum   
			- username Stanley87