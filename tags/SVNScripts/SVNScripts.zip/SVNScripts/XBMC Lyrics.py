SCRIPT = 'XBMC Lyrics'
TITLE = "Warning: %s" % ( SCRIPT )
MSG_LINE1 = "This script is not installed on your Xbox."
MSG_LINE2 = "You don't have the script needed for this button."
MSG_LINE3_ONLINE = "Would you like to download and install it?"
MSG_LINE3_OFFLINE = "Download from http://xbmc-scripting.googlecode.com/svn/trunk"

import os, sys
import xbmc, xbmcgui

if ( __name__ == '__main__' ):
    SCRIPT_PATH = 'q:\\scripts\\%s\\default.py' % ( SCRIPT, )
    if ( os.path.isfile( SCRIPT_PATH ) ):
        xbmc.executebuiltin( 'XBMC.RunScript(%s)' % ( SCRIPT_PATH, ) )
    else:
        if ( xbmc.getCondVisibility( 'system.internetstate' ) ):
            ok = xbmcgui.Dialog().yesno( TITLE, MSG_LINE1, MSG_LINE2, MSG_LINE3_ONLINE, 'skip', 'download' )
            if ( ok ):
                import svndownload
                download = svndownload.Download( script=SCRIPT )
                del download
                if ( os.path.isfile( SCRIPT_PATH ) ):
                    xbmc.executebuiltin( 'XBMC.RunScript(%s)' % ( SCRIPT_PATH, ) )
        else:
            ok = xbmcgui.Dialog().ok( TITLE, MSG_LINE1, MSG_LINE2, MSG_LINE3_OFFLINE )
