SCRIPT = "xStocks"
TITLE = "Warning! %s" % ( SCRIPT, )
MSG_LINE1 = "%s is not installed on your Xbox." % ( SCRIPT, )
MSG_LINE2_ONLINE = "Would you like to download and install it?"
MSG_LINE3_ONLINE = ""
MSG_LINE2_OFFLINE = "You may download from SVN at:"
MSG_LINE3_OFFLINE = "http://xbmc-scripting.googlecode.com/svn/trunk/%s" % ( SCRIPT.replace( " ", "%20" ), )

import os
import xbmc, xbmcgui

if ( __name__ == '__main__' ):
    SCRIPT_PATH = 'q:\\scripts\\%s\\default.py' % ( SCRIPT, )
    if ( os.path.isfile( SCRIPT_PATH ) ):
        xbmc.executebuiltin( 'XBMC.RunScript(%s)' % ( SCRIPT_PATH, ) )
    else:
        if ( xbmc.getCondVisibility( 'system.internetstate' ) ):
            ok = xbmcgui.Dialog().yesno( TITLE, MSG_LINE1, MSG_LINE2_ONLINE, MSG_LINE3_ONLINE, 'skip', 'download' )
            if ( ok ):
                import svndownload
                download = svndownload.Download( script=SCRIPT )
                del download
                if ( os.path.isfile( SCRIPT_PATH ) ):
                    xbmc.executebuiltin( 'XBMC.RunScript(%s)' % ( SCRIPT_PATH, ) )
        else:
            ok = xbmcgui.Dialog().ok( TITLE, MSG_LINE1, MSG_LINE2_OFFLINE, MSG_LINE3_OFFLINE )
